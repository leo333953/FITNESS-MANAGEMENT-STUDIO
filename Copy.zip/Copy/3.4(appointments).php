<?php



?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RMMC Admin Dashboard</title>
    <style>
        :root {  --primary-color: #1a365d; /* Dark blue */
    --secondary-color: #2b6cb0; /* Medium blue */
    --success-color: #2b6cb0; /* Green */
    --warning-color: #dd6b20; /* Orange */
    --danger-color: #e53e3e; /* Red */
    --light-bg: #ebf8ff; /* Very light blue */
    --dark-text: #2d3748; /* Dark gray/blue */
    --light-text: #f7fafc; /* Off white */
        }
        
        body {
           font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f0f5ff; /* Light blue background */
    color: var(--dark-text);
        }
        
        .container {
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar Styles */
        .sidebar {
            width: 250px;
 background-color: var(--primary-color);
    color: var(--light-text);
            padding: 20px 0;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
        }
        
        .sidebar-header {
            text-align: center;
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-nav {
                        --primary-color: #2c3e50;

            flex: 1;
            overflow-y: auto;
            padding: 20px 0;
        }
        
        .sidebar-footer {
            padding: 20px;
            border-top: 1px solid rgba(255,255,255,0.1);
        }
        
        .nav-item {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: var(--light-text);
            text-decoration: none;
            transition: all 0.3s;
            margin: 5px 0;
        }
        
        .nav-item:hover {
            background-color: rgba(255,255,255,0.1);
        }

        
        .nav-item i {
            margin-right: 10px;
            font-size: 18px;
        }
        
        .logo {
            width: 80%;
            margin: 0 auto 20px;
            display: block;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .user-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 10px;
            object-fit: cover;
        }
        
        .user-info {
            flex: 1;
        }
        
        .user-name {
            font-weight: bold;
            margin-bottom: 3px;
        }
        
        .user-role {
            font-size: 12px;
            opacity: 0.8;
        }
        
        /* Main Content Styles */
        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        
        .top-bar {
                border-bottom: 1px solid #e2e8f0; /* Light blue-gray */

            background-color: white;
            padding: 15px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            z-index: 10;
        }
        
        .page-title {
            font-size: 22px;
            font-weight: 600;
            color: var(--primary-color);
        }
        
        .user-actions {
            display: flex;
            align-items: center;
        }
        
        .notification-bell, .user-menu {
            margin-left: 20px;
            cursor: pointer;
            position: relative;
        }
        
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background-color: var(--accent-color);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .content-area {
            flex: 1;
            padding: 25px;
            overflow-y: auto;
    background-color: #f0f5ff; /* Light blue background */
        }
        
        /* Dashboard Cards */
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
            
        }
        
        .card {
            background-color: white;
    border-left: 4px solid var(--secondary-color);
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .card-title {
            font-size: 16px;
            font-weight: 600;
            color: var(--dark-text);
        }
        
        .card-icon {
                background-color: var(--secondary-color) !important;

            width: 40px;
            height: 40px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
        }
        
        .card-value {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .card-footer {
            font-size: 12px;
            color: #7f8c8d;
        }
        
        /* Tables */
        .table-container {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            overflow: hidden;
             background-color: white;
    border: 1px solid #e2e8f0;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ecf0f1;
        }
        
        th {
            background-color: var(--light-bg);
            font-weight: 600;
              background-color: #ebf8ff; /* Very light blue */
    color: var(--primary-color);
        }
        
        tr:hover {
            background-color: #f9f9f9;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .status-pending {
            background-color: #feebc8; /* Light orange */
    color: #9c4221;
        }
        
        .status-completed {
          background-color: #c6f6d5; /* Light green */
    color: #2b6cb0;
        }
        
        .status-cancelled {
           background-color: #fed7d7; /* Light red */
    color: #9b2c2c;
        }
        
        /* Forms */
        .form-container {
            background-color: white;
            border-radius: 8px;
            padding: 25px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            max-width: 900px;
            margin: 0 auto;
        }
        
        .form-title {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 20px;
            color: var(--primary-color);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }
        
        .form-control {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--secondary-color);
            outline: none;
        }
        
        .form-actions {
            display: flex;
            justify-content: flex-end;
            margin-top: 30px;
        }
        
        .btn {
            padding: 10px 20px;
            border-radius: 4px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            border: none;
        }
        
        .btn-primary {
            background-color: var(--secondary-color);
            color: white;
        }
        
        .btn-primary:hover {
    background-color: var(--secondary-color);
        }
        
        .btn-secondary {
            background-color: #95a5a6;
            color: white;
            margin-right: 10px;
        }
        
        .btn-secondary:hover {
    background-color: #2c5282; /* Darker blue */
        }
        
        .btn-danger {
    background-color: var(--danger-color);
            color: white;
        }
        
        .btn-danger:hover {
    background-color: #c53030; /* Darker red */
        }
        
        /* Section Styles */
        .section {
            display: none;
        }
        
        .section.active {
            display: block;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: auto;
            }
            
            .dashboard-cards {
                grid-template-columns: 1fr;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <img src="pictures/download.png" alt="RMMC Logo" class="logo">
                <div class="user-profile">
                    <div class="user-info">
                        <div class="user-name">Admin User</div>
                        <div class="user-role">Administrator</div>
                    </div>
                </div>
            </div>


          <div class="sidebar-nav">
                <a href="3.1(ADMINdashboard).php" class="nav-item">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                <a href="3.2(attendance).php" class="nav-item">
                    <i class="fas fa-clipboard-check"></i> Attendance
                </a>
                <a href="3.3(maintenance).php" class="nav-item">
                    <i class="fas fa-tools"></i> Maintenance
                </a>
                <a href="3.4(appointments).php" class="nav-item">
                    <i class="fas fa-calendar-alt"></i> Appointments
                </a>
                <a href="3.5(messages).php" class="nav-item active">
                    <i class="fas fa-envelope"></i> Messages
                </a>
                <a href="3.6(usermanagement).php" class="nav-item">
                    <i class="fas fa-users"></i> User Management
                </a>
                <a href="3.7(settings).php" class="nav-item">
                    <i class="fas fa-cog"></i> Settings
                </a>
            </div>
            
            <div class="sidebar-footer">
                <a href="1.1(homepage).php" class="nav-item" onclick="signOut()">
                    <i class="fas fa-sign-out-alt"></i> Sign Out
                </a>
            </div>
        </div>



        <!-- Main Content -->
    <div class="main-content">
      <div class="top-bar">
       
      </div>
      
<br>
            


            
            






<br>
<br>
<br>
<br>
<br>







                
                <!-- Appointments Section -->
                <div id="appointments-section" class="section">
                    <div class="form-container">
                        <h2 class="form-title">Appointment Scheduling</h2>
                        
                        <div class="form-actions" style="margin-bottom: 20px;">
                            <button class="btn btn-primary" onclick="showNewAppointmentForm()">
                                <i class="fas fa-plus"></i> New Appointment
                            </button>
                        </div>
                        
                        <div class="table-container">
                            <table id="appointment-table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Purpose</th>
                                        <th>Date & Time</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- Will be populated by JavaScript -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                    <!-- Appointments Section -->
                    <div class="form-container">
                        <h2 class="form-title">Appointment Scheduling</h2>
                        
                        <div class="form-actions" style="margin-bottom: 20px;">
                            <button class="btn btn-primary" onclick="showNewAppointmentForm()">
                                <i class="fas fa-plus"></i> New Appointment
                            </button>
                        </div>
                        
                        <div class="table-container">
                            <table id="appointment-table">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Purpose</th>
                                        <th>Date & Time</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- Will be populated by JavaScript -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>





    <script>
        // Sample data storage
        let attendanceRecords = [];
        let maintenanceRequests = [];
        let appointments = [];
        let users = [];
        
        // Initialize with sample data
        function initializeSampleData() {
            // Sample attendance data
            attendanceRecords = [
                { id: 1, name: "John Doe", checkIn: "2023-05-01T08:30:00", checkOut: "2023-05-01T17:00:00", notes: "Worked on project A" },
                { id: 2, name: "Jane Smith", checkIn: "2023-05-01T09:15:00", checkOut: "2023-05-01T16:45:00", notes: "Team meeting" },
                { id: 3, name: "Robert Johnson", checkIn: "2023-05-01T08:45:00", checkOut: null, notes: "Still working" }
            ];
            
            // Sample maintenance requests
            maintenanceRequests = [
                { id: 1, name: "John Doe", issue: "AC not working in room 203", urgency: "high", status: "pending", date: "2023-05-01" },
                { id: 2, name: "Jane Smith", issue: "Leaky faucet in restroom", urgency: "medium", status: "completed", date: "2023-04-28" },
                { id: 3, name: "Admin User", issue: "Broken projector in conference room", urgency: "high", status: "in-progress", date: "2023-05-02" }
            ];
            
            // Sample appointments
            appointments = [
                { id: 1, name: "John Doe", purpose: "Performance review", date: "2023-05-15", time: "14:00", status: "scheduled" },
                { id: 2, name: "Jane Smith", purpose: "Project discussion", date: "2023-05-10", time: "10:30", status: "completed" },
                { id: 3, name: "Robert Johnson", purpose: "Equipment training", date: "2023-05-05", time: "13:00", status: "scheduled" }
            ];
            
            // Sample users
            users = [
                { id: 1, name: "Admin User", email: "admin@rmmc.edu", role: "Administrator", lastLogin: "2023-05-02T08:15:00" },
                { id: 2, name: "John Doe", email: "john@rmmc.edu", role: "Faculty", lastLogin: "2023-05-02T08:30:00" },
                { id: 3, name: "Jane Smith", email: "jane@rmmc.edu", role: "Staff", lastLogin: "2023-05-02T09:00:00" }
            ];
            
            // Update dashboard counters
            updateDashboardCounters();
        }
        

        function viewUserAppointmentHistory(userName) {
    const userAppointments = appointments.filter(app => app.name === userName);
    
    let historyHTML = `<h3>Appointment History for ${userName}</h3><table class="table"><tr><th>Date</th><th>Time</th><th>Purpose</th><th>Status</th></tr>`;
    
    userAppointments.forEach(appointment => {
        historyHTML += `<tr>
            <td>${appointment.date}</td>
            <td>${appointment.time}</td>
            <td>${appointment.purpose}</td>
            <td>${appointment.status}</td>
        </tr>`;
    });
    
    historyHTML += `</table>`;
    
    const win = window.open('', '_blank');
    win.document.write(historyHTML);
}
        // Update dashboard counters
        function updateDashboardCounters() {
            document.getElementById('attendance-count').textContent = attendanceRecords.length;
            document.getElementById('maintenance-count').textContent = maintenanceRequests.filter(r => r.status !== 'completed').length;
            document.getElementById('appointments-count').textContent = appointments.filter(a => a.status === 'scheduled').length;
            document.getElementById('users-count').textContent = users.length;
        }
        
        // Show section based on menu selection
        function showSection(section) {
            // Hide all sections
            document.querySelectorAll('.section').forEach(sec => {
                sec.classList.remove('active');
            });
            
            // Show selected section
            document.getElementById(section + '-section').classList.add('active');
            
            // Update active menu item
            document.querySelectorAll('.nav-item').forEach(item => {
                item.classList.remove('active');
            });
            
            // Set active state for clicked button
            event.target.classList.add('active');
            
            // Update page title
            const titles = {
                'dashboard': 'Dashboard',
                'attendance': 'Attendance Management',
                'maintenance': 'Maintenance Requests',
                'appointments': 'Appointment Scheduling',
                'reports': 'Reports',
                'users': 'User Management',
                'settings': 'System Settings'
            };
            
            document.getElementById('page-title').textContent = titles[section];
            
            // Refresh the displayed data
            if(section === 'attendance') {
                refreshAttendanceTable();
            } else if(section === 'maintenance') {
                refreshMaintenanceTable();
            } else if(section === 'appointments') {
                refreshAppointmentTable();
            }
        }
        
        // Refresh attendance table
        function refreshAttendanceTable() {
            const tbody = document.querySelector('#attendance-table tbody');
            tbody.innerHTML = '';
            
            attendanceRecords.forEach(record => {
                const checkInTime = record.checkIn ? new Date(record.checkIn).toLocaleTimeString() : '-';
                const checkOutTime = record.checkOut ? new Date(record.checkOut).toLocaleTimeString() : '-';
                
                // Calculate duration if both check-in and check-out exist
                let duration = '-';
                if (record.checkIn && record.checkOut) {
                    const diff = new Date(record.checkOut) - new Date(record.checkIn);
                    const hours = Math.floor(diff / (1000 * 60 * 60));
                    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
                    duration = `${hours}h ${minutes}m`;
                }
                
                // Determine status
                let status = 'Completed';
                if (!record.checkOut) status = 'In Progress';
                
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${record.name}</td>
                    <td>${checkInTime}</td>
                    <td>${checkOutTime}</td>
                    <td>${duration}</td>
                    <td><span class="status-badge ${status === 'Completed' ? 'status-completed' : 'status-pending'}">${status}</span></td>
                    <td>
                        <button class="btn btn-primary" style="padding: 5px 10px; font-size: 12px;" onclick="viewAttendanceRecord(${record.id})">
                            <i class="fas fa-eye"></i>
                        </button>

                    // Add this to the row.innerHTML in refreshAppointmentTable()
    <button class="btn btn-primary" style="padding: 5px 10px; font-size: 12px; margin-right: 5px;" onclick="viewAppointment(${appointment.id})">
        <i class="fas fa-eye"></i>
    </button>
    <button class="btn btn-info" style="padding: 5px 10px; font-size: 12px; margin-right: 5px;" onclick="viewUserAppointmentHistory('${appointment.name}')">
        <i class="fas fa-history"></i>
    </button>
    <button class="btn btn-danger" style="padding: 5px 10px; font-size: 12px;" onclick="cancelAppointment(${appointment.id})">
        <i class="fas fa-times"></i>
    </button>
                `;
                
                tbody.appendChild(row);
            });
        }
        
        // Refresh maintenance table
        function refreshMaintenanceTable() {
            const tbody = document.querySelector('#maintenance-table tbody');
            tbody.innerHTML = '';
            
            maintenanceRequests.forEach(request => {
                // Determine status class
                let statusClass = '';
                if (request.status === 'completed') statusClass = 'status-completed';
                else if (request.status === 'pending') statusClass = 'status-pending';
                else if (request.status === 'in-progress') statusClass = 'status-pending';
                
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${request.id}</td>
                    <td>${request.name}</td>
                    <td>${request.issue}</td>
                    <td>${request.urgency}</td>
                    <td>${request.date}</td>
                    <td><span class="status-badge ${statusClass}">${request.status}</span></td>
                    <td>
                        <button class="btn btn-primary" style="padding: 5px 10px; font-size: 12px; margin-right: 5px;" onclick="viewMaintenanceRequest(${request.id})">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn btn-danger" style="padding: 5px 10px; font-size: 12px;" onclick="deleteMaintenanceRequest(${request.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                `;
                
                tbody.appendChild(row);
            });
        }
        
        // Refresh appointment table
        function refreshAppointmentTable() {
            const tbody = document.querySelector('#appointment-table tbody');
            tbody.innerHTML = '';
            
            appointments.forEach(appointment => {
                // Determine status class
                let statusClass = '';
                if (appointment.status === 'completed') statusClass = 'status-completed';
                else if (appointment.status === 'scheduled') statusClass = 'status-pending';
                else if (appointment.status === 'cancelled') statusClass = 'status-cancelled';
                
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${appointment.id}</td>
                    <td>${appointment.name}</td>
                    <td>${appointment.purpose}</td>
                    <td>${appointment.date} at ${appointment.time}</td>
                    <td><span class="status-badge ${statusClass}">${appointment.status}</span></td>
                    <td>
                        <button class="btn btn-primary" style="padding: 5px 10px; font-size: 12px; margin-right: 5px;" onclick="viewAppointment(${appointment.id})">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn btn-danger" style="padding: 5px 10px; font-size: 12px;" onclick="cancelAppointment(${appointment.id})">
                            <i class="fas fa-times"></i>
                        </button>
                    </td>
                `;
                
                tbody.appendChild(row);
            });
        }
        
        // View attendance record
        function viewAttendanceRecord(id) {
            const record = attendanceRecords.find(r => r.id === id);
            if (record) {
                alert(`Attendance Record\n\nName: ${record.name}\nCheck-in: ${record.checkIn ? new Date(record.checkIn).toLocaleString() : 'N/A'}\nCheck-out: ${record.checkOut ? new Date(record.checkOut).toLocaleString() : 'N/A'}\nNotes: ${record.notes || 'None'}`);
            }
        }
        
        // View maintenance request
        function viewMaintenanceRequest(id) {
            const request = maintenanceRequests.find(r => r.id === id);
            if (request) {
                alert(`Maintenance Request #${request.id}\n\nRequested By: ${request.name}\nIssue: ${request.issue}\nUrgency: ${request.urgency}\nStatus: ${request.status}\nDate: ${request.date}`);
            }
        }
        
        // Delete maintenance request
        function deleteMaintenanceRequest(id) {
            if (confirm('Are you sure you want to delete this maintenance request?')) {
                maintenanceRequests = maintenanceRequests.filter(r => r.id !== id);
                refreshMaintenanceTable();
                updateDashboardCounters();
                alert('Maintenance request deleted successfully');
            }
        }
        
        // View appointment
        function viewAppointment(id) {
            const appointment = appointments.find(a => a.id === id);
            if (appointment) {
                alert(`Appointment #${appointment.id}\n\nName: ${appointment.name}\nPurpose: ${appointment.purpose}\nDate: ${appointment.date}\nTime: ${appointment.time}\nStatus: ${appointment.status}`);
            }
        }
        
        // Cancel appointment
        function cancelAppointment(id) {
            const appointment = appointments.find(a => a.id === id);
            if (appointment && confirm(`Are you sure you want to cancel this appointment with ${appointment.name}?`)) {
                appointment.status = 'cancelled';
                refreshAppointmentTable();
                updateDashboardCounters();
                alert('Appointment cancelled successfully');
            }
        }
        
        // Show new maintenance form
        function showNewMaintenanceForm() {
            // In a real app, this would show a modal or navigate to a form page
            alert('New maintenance request form would be displayed here');
        }
        
        // Show new appointment form
        function showNewAppointmentForm() {
            // In a real app, this would show a modal or navigate to a form page
            alert('New appointment form would be displayed here');
        }
        
        // Sign out function
        function signOut() {
            if (confirm('Are you sure you want to sign out?')) {
                // In a real app, this would redirect to login page
                alert('You have been signed out');
                window.location.reload();
            }
        }
        
        // Initialize the app when page loads
        window.onload = function() {
            initializeSampleData();
            refreshAttendanceTable();
            refreshMaintenanceTable();
            refreshAppointmentTable();
        };
    </script>
</body>
</html>