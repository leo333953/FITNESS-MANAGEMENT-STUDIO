<?php
// PHP code can be added here if needed
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RMMC Admin Dashboard</title>
    <style>
        :root {
            --primary-color: #1a365d; /* Dark blue */
            --secondary-color: #2b6cb0; /* Medium blue */
            --success-color: #38a169; /* Green */
            --warning-color: #dd6b20; /* Orange */
            --danger-color: #e53e3e; /* Red */
            --light-bg: #ebf8ff; /* Very light blue */
            --dark-text: #2d3748; /* Dark gray/blue */
            --light-text: #f7fafc; /* Off white */
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f5ff; /* Light blue background */
            color: var(--dark-text);
        }
        
        .container {
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background-color: var(--primary-color);
            color: var(--light-text);
            padding: 20px 0;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
        }
        
        .sidebar-header {
            text-align: center;
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-nav {
            flex: 1;
            overflow-y: auto;
            padding: 20px 0;
        }
        
        .sidebar-footer {
            padding: 20px;
            border-top: 1px solid rgba(255,255,255,0.1);
        }
        
        .nav-item {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: var(--light-text);
            text-decoration: none;
            transition: all 0.3s;
            margin: 5px 0;
        }
        
        .nav-item:hover {
            background-color: rgba(255,255,255,0.1);
        }
        
        .nav-item i {
            margin-right: 10px;
            font-size: 18px;
        }
        
        .logo {
            width: 80%;
            margin: 0 auto 20px;
            display: block;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .user-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 10px;
            object-fit: cover;
        }
        
        .user-info {
            flex: 1;
        }
        
        .user-name {
            font-weight: bold;
            margin-bottom: 3px;
        }
        
        .user-role {
            font-size: 12px;
            opacity: 0.8;
        }
        
        /* Main Content Styles */
        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        
        .top-bar {
            border-bottom: 1px solid #e2e8f0; /* Light blue-gray */
            background-color: white;
            padding: 15px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            z-index: 10;
        }
        
        .page-title {
            font-size: 22px;
            font-weight: 600;
            color: var(--primary-color);
        }
        
        .user-actions {
            display: flex;
            align-items: center;
        }
        
        .notification-bell, .user-menu {
            margin-left: 20px;
            cursor: pointer;
            position: relative;
        }
        
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background-color: var(--accent-color);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .content-area {
            flex: 1;
            padding: 25px;
            overflow-y: auto;
            background-color: #f0f5ff; /* Light blue background */
        }
        
        /* Forms */
        .form-container {
            background-color: white;
            border-radius: 8px;
            padding: 25px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            max-width: 800px;
            margin: 0 auto;
            width: 90%;
        }
        
        .form-title {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 20px;
            color: var(--primary-color);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }
        
        .form-control {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--secondary-color);
            outline: none;
        }
        
        .btn {
            padding: 10px 20px;
            border-radius: 4px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            border: none;
        }
        
        .btn-primary {
            background-color: var(--secondary-color);
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #2c5282; /* Darker blue */
        }
        
        .btn-success {
            background-color: var(--success-color);
            color: white;
        }
        
        .btn-success:hover {
            background-color: #2f855a; /* Darker green */
        }
        
        .btn-danger {
            background-color: var(--danger-color);
            color: white;
        }
        
        .btn-danger:hover {
            background-color: #c53030; /* Darker red */
        }
        
        /* Tables */
        .table-container {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            overflow: hidden;
            background-color: white;
            border: 1px solid #e2e8f0;
            max-width: 1000px;
            margin: 20px auto 0;
            width: 90%;
            max-height: 400px; /* Set a max height for the container */
            overflow-y: auto; /* Enable vertical scrolling */
            transition: max-height 0.3s ease-in-out;
        }
        
        .table-container.collapsed {
            max-height: 150px; /* Reduced height when collapsed */
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ecf0f1;
        }
        
        th {
            background-color: #ebf8ff; /* Very light blue */
            color: var(--primary-color);
            font-weight: 600;
        }
        
        tr:hover {
            background-color: #f9f9f9;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .status-pending {
            background-color: #feebc8; /* Light orange */
            color: #9c4221;
        }
        
        .status-approved {
            background-color: #bee3f8; /* Light blue */
            color: #2b6cb0;
        }
        
        .status-completed {
            background-color: #c6f6d5; /* Light green */
            color: #276749;
        }
        
        .status-scheduled {
            background-color: #e9d8fd; /* Light purple */
            color: #553c9a;
        }
        
        .status-cancelled {
            background-color: #fed7d7; /* Light red */
            color: #9b2c2c;
        }
        
        /* Filter controls */
        .filter-controls {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .filter-controls .form-group {
            flex: 1;
        }
        
        /* Action buttons */
        .action-btn {
            padding: 5px 10px;
            font-size: 12px;
            margin: 0 2px;
            min-width: 70px;
        }
        
        /* Toggle button for table */
        .toggle-table-btn {
            display: block;
            margin: 10px auto;
            padding: 8px 15px;
            background-color: var(--secondary-color);
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .toggle-table-btn:hover {
            background-color: #2c5282;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: auto;
            }
            
            .form-container, .table-container {
                width: 95%;
            }
            
            .filter-controls {
                flex-direction: column;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <img src="pictures/download.png" alt="RMMC Logo" class="logo">
                <div class="user-profile">
                    <div class="user-info">
                        <div class="user-name">Admin User</div>
                        <div class="user-role">Administrator</div>
                    </div>
                </div>
            </div>

            <div class="sidebar-nav">
                <a href="3.1(ADMINdashboard).php" class="nav-item">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                <a href="3.2(attendance).php" class="nav-item">
                    <i class="fas fa-clipboard-check"></i> Attendance
                </a>
                <a href="3.3(maintenance).php" class="nav-item">
                    <i class="fas fa-tools"></i> Maintenance
                </a>
                <a href="3.4(appointments).php" class="nav-item active">
                    <i class="fas fa-calendar-alt"></i> Appointments
                </a>
                <a href="3.5(messages).php" class="nav-item">
                    <i class="fas fa-envelope"></i> Messages
                </a>
                <a href="3.6(usermanagement).php" class="nav-item">
                    <i class="fas fa-users"></i> User Management
                </a>
                <a href="3.7(settings).php" class="nav-item">
                    <i class="fas fa-cog"></i> Settings
                </a>
            </div>
            
            <div class="sidebar-footer">
                <a href="1.1(homepage).php" class="nav-item" onclick="signOut()">
                    <i class="fas fa-sign-out-alt"></i> Sign Out
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="top-bar">
                <div class="page-title">Appointment Management</div>
            </div>
            
            <div class="content-area">
                <div class="form-container">
                    <h2 class="form-title">Appointment Scheduling</h2>
                    
                    <div class="filter-controls">
                        <div class="form-group">
                            <label class="form-label">Filter by User</label>
                            <input type="text" class="form-control" id="user-filter" placeholder="Search by name..." oninput="refreshAppointmentTable()">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Filter by Status</label>
                            <select class="form-control" id="status-filter" onchange="refreshAppointmentTable()">
                                <option value="all">All Statuses</option>
                                <option value="pending">Pending Approval</option>
                                <option value="approved">Approved</option>
                                <option value="scheduled">Scheduled</option>
                                <option value="rejected">Rejected</option>
                                <option value="completed">Completed</option>
                            </select>
                        </div>
                    </div>
                    
                    <button class="toggle-table-btn" onclick="toggleTable()">
                        <i class="fas fa-chevron-down" id="toggle-icon"></i> Toggle Table
                    </button>
                    
                    <div class="table-container" id="appointment-table-container">
                        <table id="appointment-table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Purpose</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Will be populated by JavaScript -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Initialize with sample data if none exists
        function initializeAppointmentData() {
            if(!localStorage.getItem('appointments')) {
                const sampleAppointments = [
                    {
                        id: 1,
                        name: "John Doe",
                        purpose: "Consultation",
                        date: new Date(Date.now() + 86400000).toISOString().split('T')[0],
                        time: "10:00",
                        status: "pending",
                        adminNotes: ""
                    },
                    {
                        id: 2,
                        name: "Jane Smith",
                        purpose: "Follow-up",
                        date: new Date(Date.now() + 172800000).toISOString().split('T')[0],
                        time: "14:30",
                        status: "approved",
                        adminNotes: "Needs lab work"
                    },
                    {
                        id: 3,
                        name: "Mike Johnson",
                        purpose: "Annual Checkup",
                        date: new Date(Date.now() + 259200000).toISOString().split('T')[0],
                        time: "09:15",
                        status: "scheduled",
                        adminNotes: "Room 5 assigned"
                    }
                ];
                localStorage.setItem('appointments', JSON.stringify(sampleAppointments));
            }
        }

        // Toggle table visibility
        function toggleTable() {
            const container = document.getElementById('appointment-table-container');
            const icon = document.getElementById('toggle-icon');
            
            container.classList.toggle('collapsed');
            
            if (container.classList.contains('collapsed')) {
                icon.classList.remove('fa-chevron-down');
                icon.classList.add('fa-chevron-up');
            } else {
                icon.classList.remove('fa-chevron-up');
                icon.classList.add('fa-chevron-down');
            }
        }

        // Refresh appointment table with filters
        function refreshAppointmentTable() {
            const tbody = document.querySelector('#appointment-table tbody');
            tbody.innerHTML = '';
            
            // Get filter values
            const userFilter = document.getElementById('user-filter').value.toLowerCase();
            const statusFilter = document.getElementById('status-filter').value;
            
            // Get all records from localStorage
            let appointments = JSON.parse(localStorage.getItem('appointments')) || [];
            
            // Apply filters
            let filteredAppointments = appointments;
            if (userFilter) {
                filteredAppointments = filteredAppointments.filter(app => 
                    app.name.toLowerCase().includes(userFilter)
                );
            }
            if (statusFilter !== 'all') {
                filteredAppointments = filteredAppointments.filter(app => app.status === statusFilter);
            }
            
            filteredAppointments.forEach(appointment => {
                // Determine status class
                let statusClass = '';
                if (appointment.status === 'completed') statusClass = 'status-completed';
                else if (appointment.status === 'approved') statusClass = 'status-approved';
                else if (appointment.status === 'pending') statusClass = 'status-pending';
                else if (appointment.status === 'rejected') statusClass = 'status-cancelled';
                else if (appointment.status === 'scheduled') statusClass = 'status-scheduled';
                
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${appointment.name}</td>
                    <td>${appointment.purpose}</td>
                    <td>${appointment.date}</td>
                    <td>${appointment.time}</td>
                    <td><span class="status-badge ${statusClass}">${appointment.status}</span></td>
                    <td>
                        <button class="btn btn-primary action-btn" onclick="viewAppointment(${appointment.id})">
                            <i class="fas fa-eye"></i> View
                        </button>
                        ${appointment.status === 'pending' ? `
                        <button class="btn btn-success action-btn" onclick="approveAppointment(${appointment.id})">
                            <i class="fas fa-check"></i> Approve
                        </button>
                        <button class="btn btn-danger action-btn" onclick="rejectAppointment(${appointment.id})">
                            <i class="fas fa-times"></i> Reject
                        </button>` : ''}
                        ${appointment.status === 'approved' ? `
                        <button class="btn btn-success action-btn" onclick="scheduleAppointment(${appointment.id})">
                            <i class="fas fa-calendar-check"></i> Schedule
                        </button>` : ''}
                        ${appointment.status === 'scheduled' ? `
                        <button class="btn btn-success action-btn" onclick="completeAppointment(${appointment.id})">
                            <i class="fas fa-check-circle"></i> Complete
                        </button>` : ''}
                        <button class="btn btn-danger action-btn" onclick="deleteAppointment(${appointment.id})">
                            <i class="fas fa-trash"></i> Delete
                        </button>
                        <button class="btn btn-info action-btn" onclick="viewUserAppointmentHistory('${appointment.name}')">
                            <i class="fas fa-history"></i> History
                        </button>
                    </td>
                `;
                
                tbody.appendChild(row);
            });
        }

        // View appointment details
        function viewAppointment(appointmentId) {
            let appointments = JSON.parse(localStorage.getItem('appointments')) || [];
            const appointment = appointments.find(a => a.id === appointmentId);
            
            if (appointment) {
                let notes = prompt("View/Edit Admin Notes:", appointment.adminNotes || "");
                if (notes !== null) {
                    appointment.adminNotes = notes;
                    localStorage.setItem('appointments', JSON.stringify(appointments));
                    refreshAppointmentTable();
                }
            }
        }

        // Approve appointment
        function approveAppointment(appointmentId) {
            if(confirm('Approve this appointment?')) {
                let appointments = JSON.parse(localStorage.getItem('appointments')) || [];
                const appIndex = appointments.findIndex(a => a.id === appointmentId);
                
                if(appIndex !== -1) {
                    appointments[appIndex].status = 'approved';
                    localStorage.setItem('appointments', JSON.stringify(appointments));
                    refreshAppointmentTable();
                    alert('Appointment approved');
                }
            }
        }

        // Schedule appointment (after approval)
        function scheduleAppointment(appointmentId) {
            let appointments = JSON.parse(localStorage.getItem('appointments')) || [];
            const appIndex = appointments.findIndex(a => a.id === appointmentId);
            
            if(appIndex !== -1) {
                const room = prompt("Enter room number for scheduling:");
                if (room !== null) {
                    appointments[appIndex].status = 'scheduled';
                    appointments[appIndex].adminNotes = `Scheduled in Room ${room}`;
                    localStorage.setItem('appointments', JSON.stringify(appointments));
                    refreshAppointmentTable();
                    alert('Appointment scheduled');
                }
            }
        }

        // Reject appointment
        function rejectAppointment(appointmentId) {
            if(confirm('Reject this appointment?')) {
                let appointments = JSON.parse(localStorage.getItem('appointments')) || [];
                const appIndex = appointments.findIndex(a => a.id === appointmentId);
                
                if(appIndex !== -1) {
                    const reason = prompt("Enter reason for rejection:");
                    if (reason !== null) {
                        appointments[appIndex].status = 'rejected';
                        appointments[appIndex].adminNotes = `Rejected: ${reason}`;
                        localStorage.setItem('appointments', JSON.stringify(appointments));
                        refreshAppointmentTable();
                        alert('Appointment rejected');
                    }
                }
            }
        }

        // Complete appointment
        function completeAppointment(appointmentId) {
            if(confirm('Mark this appointment as completed?')) {
                let appointments = JSON.parse(localStorage.getItem('appointments')) || [];
                const appIndex = appointments.findIndex(a => a.id === appointmentId);
                
                if(appIndex !== -1) {
                    appointments[appIndex].status = 'completed';
                    localStorage.setItem('appointments', JSON.stringify(appointments));
                    refreshAppointmentTable();
                    alert('Appointment marked as completed');
                }
            }
        }

        // Delete appointment
        function deleteAppointment(appointmentId) {
            if(confirm('Are you sure you want to delete this appointment?')) {
                let appointments = JSON.parse(localStorage.getItem('appointments')) || [];
                const filteredAppointments = appointments.filter(a => a.id !== appointmentId);
                
                localStorage.setItem('appointments', JSON.stringify(filteredAppointments));
                refreshAppointmentTable();
                alert('Appointment deleted');
            }
        }

        // View user's appointment history
        function viewUserAppointmentHistory(userName) {
            let appointments = JSON.parse(localStorage.getItem('appointments')) || [];
            const userAppointments = appointments.filter(a => a.name === userName);
            
            if (userAppointments.length > 0) {
                let history = `Appointment History for ${userName}:\n\n`;
                userAppointments.forEach(app => {
                    history += `Date: ${app.date} ${app.time}\n`;
                    history += `Purpose: ${app.purpose}\n`;
                    history += `Status: ${app.status}\n`;
                    if (app.adminNotes) history += `Notes: ${app.adminNotes}\n`;
                    history += `------------------------\n`;
                });
                
                alert(history);
            } else {
                alert(`No appointment history found for ${userName}`);
            }
        }

        // Initialize when page loads
        window.onload = function() {
            initializeAppointmentData();
            refreshAppointmentTable();
        };
    </script>
</body>
</html>