<?php
session_start();
session_unset();
session_destroy();
header("Location: 1.1(homepage).php");
exit();
?>