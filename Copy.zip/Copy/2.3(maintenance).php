<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RMMC User Dashboard</title>
    <style>
        :root {
            --primary-color: #1a365d; /* Dark blue */
            --secondary-color: #2b6cb0; /* Medium blue */
            --success-color: #38a169; /* Green */
            --warning-color: #dd6b20; /* Orange */
            --danger-color: #e53e3e; /* Red */
            --light-bg: #ebf8ff; /* Very light blue */
            --dark-text: #2d3748; /* Dark gray/blue */
            --light-text: #f7fafc; /* Off white */
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f5ff; /* Light blue background */
            color: var(--dark-text);
        }
        
        .container {
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background-color: var(--primary-color);
            color: var(--light-text);
            padding: 20px 0;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
        }
        
        .sidebar-header {
            text-align: center;
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-nav {
            flex: 1;
            overflow-y: auto;
            padding: 20px 0;
        }
        
        .sidebar-footer {
            padding: 20px;
            border-top: 1px solid rgba(255,255,255,0.1);
        }
        
        .nav-item {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: var(--light-text);
            text-decoration: none;
            transition: all 0.3s;
            margin: 5px 0;
        }
        
        .nav-item:hover {
            background-color: rgba(255,255,255,0.1);
        }
        
       
        .nav-item i {
            margin-right: 10px;
            font-size: 18px;
        }
        
        .logo {
            width: 80%;
            margin: 0 auto 20px;
            display: block;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .user-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 10px;
            object-fit: cover;
        }
        
        .user-info {
            flex: 1;
        }
        
        .user-name {
            font-weight: bold;
            margin-bottom: 3px;
        }
        
        .user-role {
            font-size: 12px;
            opacity: 0.8;
        }
        
        /* Main Content Styles */
        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        
        .top-bar {
            border-bottom: 1px solid #e2e8f0; /* Light blue-gray */
            background-color: white;
            padding: 15px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            z-index: 10;
        }
        
        .page-title {
            font-size: 22px;
            font-weight: 600;
            color: var(--primary-color);
        }
        
        .user-actions {
            display: flex;
            align-items: center;
        }
        
        .notification-bell, .user-menu {
            margin-left: 20px;
            cursor: pointer;
            position: relative;
        }
        
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background-color: var(--accent-color);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .content-area {
            flex: 1;
            padding: 25px;
            overflow-y: auto;
            background-color: #f0f5ff; /* Light blue background */
        }
        
        /* Dashboard Cards */
        .dashboard-cards {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
            justify-content: center; /* Center the cards */
            gap: 20px; /* Space between cards */
        }
        
        .card {
            background-color: white;
            border-left: 4px solid var(--secondary-color);
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            flex: 1;
            max-width: 300px;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .card-header {
            display: flex;
            justify-content: center; /* Center the card header */
            align-items: center;
            margin-bottom: 15px; /* Space below the header */
        }
        .card-title {
            margin-right: 10px; /* Space between title and icon */
            font-weight: 600; /* Optional: Make the title bold */
        }
        .card-icon {
            background-color: var(--secondary-color) !important;
            width: 40px;
            height: 40px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            margin-left: 10px; /* Optional: Space to the left of the icon */
        }
        
        .card-value {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 5px;
            text-align: center;
        }
        
        .card-footer {
            font-size: 12px;
            color: #7f8c8d;
            text-align: center;
        }
        
        /* Forms */
        .form-container {
            background-color: white;
            border-radius: 8px;
            padding: 25px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            max-width: 400px; /* Reduced from 800px */
            margin: 0 auto;
            width: 90%;
        }
        
        .form-title {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 20px;
            color: var(--primary-color);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }
        
        .form-control {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--secondary-color);
            outline: none;
        }
        
        .btn {
            padding: 10px 20px;
            border-radius: 4px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            border: none;
        }
        
        .btn-primary {
            background-color: var(--secondary-color);
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #2c5282; /* Darker blue */
        }
        
        .btn-success {
            background-color: var(--success-color);
            color: white;
        }
        
        .btn-success:hover {
            background-color: #2f855a; /* Darker green */
        }
        
        /* Tables */
        .table-container {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            overflow: hidden;
            background-color: white;
            border: 1px solid #e2e8f0;
            max-width: 800px; /* Reduced from 1000px */
            margin: 20px auto 0;
            width: 90%;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ecf0f1;
        }
        
        th {
            background-color: #ebf8ff; /* Very light blue */
            color: var(--primary-color);
            font-weight: 600;
        }
        
        tr:hover {
            background-color: #f9f9f9;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .status-pending {
            background-color: #feebc8; /* Light orange */
            color: #9c4221;
        }
        
        .status-completed {
            background-color: #c6f6d5; /* Light green */
            color: #276749;
        }
        
        /* Section styles */
        .section {
            display: none;
        }
        
        .section.active {
            display: block;
        }
        
        /* Dashboard logo styles */
        .dashboard-logo {
            display: block;
            width: 500px;
            max-width: 80%;
            margin: 0 auto 30px;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: auto;
            }
            
            .dashboard-cards {
                flex-direction: column;
                align-items: center;
            }
            
            .card {
                max-width: 100%;
                width: 100%;
            }
            
            .form-container, .table-container {
                width: 95%;
            }
            
            .dashboard-logo {
                width: 300px;
            }
        }
    </style>

    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <img src="pictures/download.png" alt="RMMC Logo" class="logo">
                <div class="user-profile">
                    <div class="user-info">
                        <div class="user-name">User Name</div>
                        <div class="user-role">Student/Staff</div>
                    </div>
                </div>
            </div>
            
             <div class="sidebar-nav">
                <a href="2.1(USERdashboard).php" class="nav-item active" onclick="showSection('dashboard', this)">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                  <a href="2.0(account).php" class="nav-item" onclick="showSection('attendance', this)">
    <i class="fas fa-user"></i> Account
</a>

                </a>
                <a href="2.2(attendance).php" class="nav-item" onclick="showSection('attendance', this)">
                    <i class="fas fa-clipboard-check"></i> Attendance
                </a>
                <a href="2.3(maintenance).php" class="nav-item" onclick="showSection('maintenance', this)">
                    <i class="fas fa-tools"></i> Maintenance
                </a>
                <a href="2.4(appointments).php" class="nav-item" onclick="showSection('appointments', this)">
                    <i class="fas fa-calendar-alt"></i> Appointments
                </a>

                 <a href="2.6(messages).php" class="nav-item">
                    <i class="fas fa-envelope"></i> Messages
                </a>

                <a href="2.5(history).php" class="nav-item" onclick="showSection('history', this)">
                    <i class="fas fa-history"></i> History
                </a>

                      
            <div class="sidebar-footer">
                <a href="1.1(homepage).php" class="nav-item" onclick="signOut()">
                    <i class="fas fa-sign-out-alt"></i> Sign Out
                </a>
            </div>
            </div>
           
        </div>
        
        <!-- Main Content -->
    <div class="main-content">
      <div class="top-bar">
       
      </div>
      
<br>
            



            
<br>

<br>

<br>
<br>


              <!-- Maintenance Section -->
                    <div class="form-container">
                        <h2 class="form-title">Maintenance Requests</h2>
                        
                        <div class="form-group">
                            <label class="form-label">Your Name</label>
                            <input type="text" class="form-control" id="maintenance-name" placeholder="Enter your name">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Issue Description</label>
                            <textarea class="form-control" id="maintenance-issue" rows="4" placeholder="Describe the issue"></textarea>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Urgency Level</label>
                            <select class="form-control" id="maintenance-urgency">
                                <option value="low">Low</option>
                                <option value="medium">Medium</option>
                                <option value="high">High</option>
                            </select>
                        </div>
                        
                        <button class="btn btn-primary" onclick="submitMaintenance()" style="width: 100%;">
                            <i class="fas fa-paper-plane"></i> Submit Request
                        </button>
                    </div>
                    
                   
                </div>

                         
    <script>
    // Data storage for maintenance requests
    let maintenanceRequests = [];
    let currentUser = null;
    
    // Initialize with saved data
    function initializeSampleData() {
        if(localStorage.getItem('maintenanceRequests')) {
            maintenanceRequests = JSON.parse(localStorage.getItem('maintenanceRequests'));
        }
    }
    
   // In the submitMaintenance function:
function submitMaintenance() {
    const name = document.getElementById('maintenance-name').value;
    const issue = document.getElementById('maintenance-issue').value;
    const urgency = document.getElementById('maintenance-urgency').value;
    
    if(!name || !issue) {
        alert('Please fill in all required fields');
        return;
    }
    
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0];
    
    const newRequest = {
        id: Date.now(),
        name: name,
        issue: issue,
        urgency: urgency,
        status: "pending",
        date: dateStr,
        type: 'maintenance' // Add type identifier
    };
    
    // Get existing requests or initialize empty array
    let requests = JSON.parse(localStorage.getItem('maintenanceRequests')) || [];
    requests.push(newRequest);
    localStorage.setItem('maintenanceRequests', JSON.stringify(requests));
    
    // Clear form
    document.getElementById('maintenance-name').value = '';
    document.getElementById('maintenance-issue').value = '';
    document.getElementById('maintenance-urgency').value = 'low';
    
    alert('Maintenance request submitted successfully');
}
   
</script>
</body>
</html>