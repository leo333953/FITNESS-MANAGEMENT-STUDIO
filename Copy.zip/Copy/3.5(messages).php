<?php
// Initialize session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Sample message storage (in a real app, this would be a database)
if (!isset($_SESSION['messages'])) {
    $_SESSION['messages'] = [
        [
            'id' => 1,
            'subject' => 'System Maintenance',
            'content' => 'There will be scheduled maintenance this Saturday from 2-4 AM. The system may be unavailable during this time.',
            'recipients' => 'All Users',
            'date' => '2023-05-10 09:30:00',
            'sender' => 'Admin User'
        ],
        [
            'id' => 2,
            'subject' => 'New Feature Announcement',
            'content' => 'We have added a new reporting feature to the dashboard. Please check it out and provide feedback.',
            'recipients' => 'Faculty',
            'date' => '2023-05-08 14:15:00',
            'sender' => 'Admin User'
        ]
    ];
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_message'])) {
    $newMessage = [
        'id' => count($_SESSION['messages']) + 1,
        'subject' => htmlspecialchars($_POST['subject']),
        'content' => htmlspecialchars($_POST['content']),
        'recipients' => htmlspecialchars($_POST['recipients']),
        'date' => date('Y-m-d H:i:s'),
        'sender' => 'Admin User'
    ];
    
    array_unshift($_SESSION['messages'], $newMessage);
    
    // Redirect to prevent form resubmission
    header("Location: ".$_SERVER['PHP_SELF']."?sent=1");
    exit();
}

// Check if message was just sent
$messageSent = isset($_GET['sent']) && $_GET['sent'] == 1;
?>






<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RMMC Admin Dashboard - Messages</title>
    <style>
        :root {  
            --primary-color: #1a365d; /* Dark blue */
            --secondary-color: #2b6cb0; /* Medium blue */
            --success-color: #38a169; /* Green */
            --warning-color: #dd6b20; /* Orange */
            --danger-color: #e53e3e; /* Red */
            --light-bg: #ebf8ff; /* Very light blue */
            --dark-text: #2d3748; /* Dark gray/blue */
            --light-text: #f7fafc; /* Off white */
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f5ff; /* Light blue background */
            color: var(--dark-text);
        }
        
        .container {
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background-color: var(--primary-color);
            color: var(--light-text);
            padding: 20px 0;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
        }
        
        .sidebar-header {
            text-align: center;
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-nav {
            --primary-color: #2c3e50;
            flex: 1;
            overflow-y: auto;
            padding: 20px 0;
        }
        
        .sidebar-footer {
            padding: 20px;
            border-top: 1px solid rgba(255,255,255,0.1);
        }
        
        .nav-item {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: var(--light-text);
            text-decoration: none;
            transition: all 0.3s;
            margin: 5px 0;
        }
        
        .nav-item:hover {
            background-color: rgba(255,255,255,0.1);
        }

        .nav-item i {
            margin-right: 10px;
            font-size: 18px;
        }
        
        .logo {
            width: 80%;
            margin: 0 auto 20px;
            display: block;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .user-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 10px;
            object-fit: cover;
        }
        
        .user-info {
            flex: 1;
        }
        
        .user-name {
            font-weight: bold;
            margin-bottom: 3px;
        }
        
        .user-role {
            font-size: 12px;
            opacity: 0.8;
        }
        
        /* Main Content Styles */
        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        
        .top-bar {
            border-bottom: 1px solid #e2e8f0;
            background-color: white;
            padding: 15px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            z-index: 10;
        }
        
        .page-title {
            font-size: 22px;
            font-weight: 600;
            color: var(--primary-color);
        }
        
        .user-actions {
            display: flex;
            align-items: center;
        }
        
        .notification-bell, .user-menu {
            margin-left: 20px;
            cursor: pointer;
            position: relative;
        }
        
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background-color: var(--accent-color);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .content-area {
            flex: 1;
            padding: 25px;
            overflow-y: auto;
            background-color: #f0f5ff;
        }
        
        /* Message-specific styles */
        .messages-container {
            display: flex;
            flex: 1;
            overflow: hidden;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        
        .message-list {
            width: 300px;
            border-right: 1px solid #e2e8f0;
            overflow-y: auto;
        }
        
        .message-content {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            background-color: #f8fafc;
        }
        
        .message-item {
            padding: 15px;
            border-bottom: 1px solid #e2e8f0;
            cursor: pointer;
            transition: background-color 0.2s;
        }
        
        .message-item:hover {
            background-color: var(--light-bg);
        }
        
        .message-item.active {
            background-color: var(--light-bg);
            border-left: 3px solid var(--secondary-color);
        }
        
        .message-subject {
            font-weight: 600;
            margin-bottom: 5px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .message-preview {
            font-size: 13px;
            color: #4a5568;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .message-meta {
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: #718096;
            margin-top: 5px;
        }
        
        .message-header {
            border-bottom: 1px solid #e2e8f0;
            padding-bottom: 15px;
            margin-bottom: 15px;
        }
        
        .message-title {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .message-sender {
            color: var(--secondary-color);
            font-weight: 500;
        }
        
        .message-date {
            color: #718096;
            font-size: 14px;
        }
        
        .message-recipients {
            background-color: #e6fffa;
            color: #234e52;
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 12px;
            display: inline-block;
            margin-top: 5px;
        }
        
        .message-body {
            line-height: 1.6;
            white-space: pre-wrap;
        }
        
        /* New message form */
        .new-message-form {
            background-color: white;
            border-radius: 8px;
            padding: 25px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            max-width: 800px;
            margin: 0 auto;
        }
        
        .form-title {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 20px;
            color: var(--primary-color);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }
        
        .form-control {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        textarea.form-control {
            min-height: 150px;
            resize: vertical;
        }
        
        .form-control:focus {
            border-color: var(--secondary-color);
            outline: none;
        }
        
        .form-actions {
            display: flex;
            justify-content: flex-end;
            margin-top: 30px;
        }
        
        .btn {
            padding: 10px 20px;
            border-radius: 4px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            border: none;
        }
        
        .btn-primary {
            background-color: var(--secondary-color);
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #2c5282;
        }
        
        .btn-secondary {
            background-color: #95a5a6;
            color: white;
            margin-right: 10px;
        }
        
        .btn-secondary:hover {
            background-color: #7f8c8d;
        }
        
        /* Tabs */
        .message-tabs {
            display: flex;
            border-bottom: 1px solid #e2e8f0;
            margin-bottom: 20px;
        }
        
        .message-tab {
            padding: 10px 20px;
            cursor: pointer;
            border-bottom: 2px solid transparent;
        }
        
        .message-tab.active {
            border-bottom-color: var(--secondary-color);
            color: var(--secondary-color);
            font-weight: 500;
        }
        
        .message-tab-content {
            display: none;
        }
        
        .message-tab-content.active {
            display: block;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: auto;
            }
            
            .messages-container {
                flex-direction: column;
            }
            
            .message-list {
                width: 100%;
                border-right: none;
                border-bottom: 1px solid #e2e8f0;
                max-height: 200px;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <img src="pictures/download.png" alt="RMMC Logo" class="logo">
                <div class="user-profile">
                    <div class="user-info">
                        <div class="user-name">Admin User</div>
                        <div class="user-role">Administrator</div>
                    </div>
                </div>
            </div>

            <div class="sidebar-nav">
                <a href="3.1(ADMINdashboard).php" class="nav-item">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                <a href="3.2(attendance).php" class="nav-item">
                    <i class="fas fa-clipboard-check"></i> Attendance
                </a>
                <a href="3.3(maintenance).php" class="nav-item">
                    <i class="fas fa-tools"></i> Maintenance
                </a>
                <a href="3.4(appointments).php" class="nav-item">
                    <i class="fas fa-calendar-alt"></i> Appointments
                </a>
                <a href="3.5(messages).php" class="nav-item active">
                    <i class="fas fa-envelope"></i> Messages
                </a>
                <a href="3.6(usermanagement).php" class="nav-item">
                    <i class="fas fa-users"></i> User Management
                </a>
                <a href="3.7(settings).php" class="nav-item">
                    <i class="fas fa-cog"></i> Settings
                </a>
            </div>
            
            <div class="sidebar-footer">
                <a href="1.1(homepage).php" class="nav-item" onclick="signOut()">
                    <i class="fas fa-sign-out-alt"></i> Sign Out
                </a>
            </div>
        </div>
        
        <!-- Main Content -->
        <div class="main-content">
            <div class="top-bar">
                <div class="page-title" id="page-title">Messages</div>
                <div class="user-actions">
                    <div class="notification-bell">
                        <i class="fas fa-bell"></i>
                        <span class="notification-badge">3</span>
                    </div>
                    <div class="user-menu">
                        <i class="fas fa-user-circle" style="font-size: 24px;"></i>
                    </div>
                </div>
            </div>
            
            <div class="content-area">
                <div class="message-tabs">
                    <div class="message-tab active" onclick="showMessageTab('inbox')">
                        <i class="fas fa-inbox"></i> Sent Messages
                    </div>
                    <div class="message-tab" onclick="showMessageTab('compose')">
                        <i class="fas fa-pencil-alt"></i> Compose New
                    </div>
                </div>
                
                <!-- Inbox Tab -->
                <div id="inbox-tab" class="message-tab-content active">
                    <div class="messages-container">
                        <div class="message-list">
                            <?php foreach ($_SESSION['messages'] as $message): ?>
                                <div class="message-item" onclick="showMessage(<?= $message['id'] ?>)">
                                    <div class="message-subject"><?= htmlspecialchars($message['subject']) ?></div>
                                    <div class="message-preview"><?= substr(htmlspecialchars($message['content']), 0, 50) ?>...</div>
                                    <div class="message-meta">
                                        <span><?= date('M j, Y', strtotime($message['date'])) ?></span>
                                        <span><?= htmlspecialchars($message['recipients']) ?></span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        
                        <div class="message-content" id="message-content">
                            <div style="text-align: center; padding: 50px; color: #718096;">
                                <i class="fas fa-envelope-open-text" style="font-size: 48px; margin-bottom: 15px;"></i>
                                <h3>Select a message to view</h3>
                                <p>Click on any message in the list to view its contents</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Compose Tab -->
                <div id="compose-tab" class="message-tab-content">
                    <div class="new-message-form">
                        <h2 class="form-title">Compose New Message</h2>
                        <form method="POST" action="">
                            <div class="form-group">
                                <label class="form-label">Recipients</label>
                                <select class="form-control" name="recipients" required>
                                    <option value="All Users">All Users</option>
                                    <option value="Administrators">Administrators</option>
                                    <option value="Faculty">Faculty</option>
                                    <option value="Staff">Staff</option>
                                    <option value="Students">Students</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">Subject</label>
                                <input type="text" class="form-control" name="subject" placeholder="Enter message subject" required>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">Message</label>
                                <textarea class="form-control" name="content" placeholder="Type your message here..." required></textarea>
                            </div>
                            
                            <div class="form-actions">
                                <button type="button" class="btn btn-secondary" onclick="showMessageTab('inbox')">Cancel</button>
                                <button type="submit" class="btn btn-primary" name="send_message">Send Message</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Show message content
        function showMessage(id) {
            // In a real app, this would fetch the message content from the server
            const messages = <?php echo json_encode($_SESSION['messages']); ?>;
            const message = messages.find(m => m.id == id);
            
            if (message) {
                const messageHtml = `
                    <div class="message-header">
                        <h2 class="message-title">${message.subject}</h2>
                        <div class="message-meta">
                            <span class="message-sender">From: ${message.sender}</span>
                            <span class="message-date">${new Date(message.date).toLocaleString()}</span>
                        </div>
                        <div class="message-recipients">To: ${message.recipients}</div>
                    </div>
                    <div class="message-body">${message.content.replace(/\n/g, '<br>')}</div>
                `;
                
                document.getElementById('message-content').innerHTML = messageHtml;
                
                // Highlight the selected message
                document.querySelectorAll('.message-item').forEach



            }

        }
