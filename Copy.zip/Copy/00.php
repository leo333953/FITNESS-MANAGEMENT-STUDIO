<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

// Database connection
$db = new mysqli('localhost', 'username', 'password', 'fitness_studio');
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// User roles and initial admin user
$users = [
    'admin' => ['password' => 'password123', 'role' => 'admin'],
    'user1' => ['password' => 'userpass', 'role' => 'user1']
];

// Main routing logic
$page = isset($_GET['page']) ? $_GET['page'] : 'login';

// Generate CSRF token if not set
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Process forms
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'login':
                handleLogin();
                break;
            case 'register':
                handleRegistration();
                break;
        }
    }
}

function handleLogin() {
    global $users;
    
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['error'] = "Invalid CSRF token...";
        return;
    }
    
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (isset($users[$username]) && $users[$username]['password'] === $password) {
        $_SESSION['username'] = $username;
        $_SESSION['role'] = $users[$username]['role'];

        if ($users[$username]['role'] === 'user1') {
            $_SESSION['success'] = "Login successful! Redirecting...";
            header("Location: ?container=user_dashboard");
        } else {
            $_SESSION['success'] = "Login successful! Redirecting...";
            header("Location: ?container=admin_dashboard");
        }
        exit();
    } else {
        $_SESSION['error'] = "Invalid username or password.";
    }
}

function handleRegistration() {
    global $db;
    
    $required_fields = ['family_name', 'given_name', 'middle_initial', 'email', 'phone_number', 'password', 'role'];
    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
            $_SESSION['error'] = "All fields are required.";
            header("Location: ?container=register");
            exit();
        }
    }
    
    $family_name = $db->real_escape_string($_POST['family_name']);
    $given_name = $db->real_escape_string($_POST['given_name']);
    $middle_initial = $db->real_escape_string($_POST['middle_initial']);
    $email = $db->real_escape_string($_POST['email']);
    $phone_number = $db->real_escape_string($_POST['phone_number']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $db->real_escape_string($_POST['role']);
    $sports_expertise = isset($_POST['sports_expertise']) ? $db->real_escape_string($_POST['sports_expertise']) : '';
    
    $sql = "INSERT INTO users (family_name, given_name, middle_initial, email, phone_number, password, role, sports_expertise) 
            VALUES ('$family_name', '$given_name', '$middle_initial', '$email', '$phone_number', '$password', '$role', '$sports_expertise')";
    
    if ($db->query($sql)) {
        $_SESSION['success'] = "Registration successful!";
        if ($role === 'student') {
            header("Location: ?container=student");
        } elseif ($role === 'teachers') {
            header("Location: ?container=teachers");
        } else {
            header("Location: ?container=staff");
        }
        exit();
    } else {
        $_SESSION['error'] = "Registration failed: " . $db->error;
        header("Location: ?container=register");
        exit();
    }
}

function showLoginContainer() {
    global $users;
    ?>
    <div class="container">
        <div class="left-panel">
            <img src="logo.png" alt="Fitness Image" class="logo">
            <h1>STUDIO</h1>
        </div>
        <div class="right-panel">
            <h1>Ramon Magsaysay Memorial Colleges</h1>
            <h2>General Santos City</h2>
            <img src="high_quality_logo.png" alt="school-logo" class="logos">

            <?php if (isset($_SESSION['success'])): ?>
                <div class='notification-container' id='successContainer'>
                    <div class='notification-content'>
                        <div class='spinner'></div>
                        <div class='notification-text'><?= $_SESSION['success'] ?></div>
                    </div>
                </div>
                <script>document.getElementById('successContainer').style.display = 'flex';</script>
                <?php unset($_SESSION['success']); ?>
            <?php endif; ?>

            <?php if (isset($_SESSION['error'])): ?>
                <div class='notification-container' id='errorContainer'>
                    <div class='notification-content'>
                        <div class='error-icon'>✕</div>
                        <div class='notification-text'><?= $_SESSION['error'] ?></div>
                    </div>
                </div>
                <script>
                    document.getElementById('errorContainer').style.display = 'flex';
                    setTimeout(function() {
                        document.getElementById('errorContainer').style.display = 'none';
                    }, 2000);
                </script>
                <?php unset($_SESSION['error']); ?>
            <?php endif; ?>

            <form class="login-form" method="POST">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <input type="hidden" name="action" value="login">
                
                <label for="username">Username/Email</label>
                <input type="text" id="username" name="username" required>

                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
                <span style="display:inline-flex;align-items:center;margin-left:5px;">
                    <input type="checkbox" id="show-password" style="margin-left:10px;"/>
                    <label for="show-password" style="margin-left:5px; font-size:13px; cursor:pointer;">Show Password</label>
                </span>

                <div class="login-button-container">
                    <button type="submit">Login</button>
                </div>

                <div class="links">
                    <a href="#">Forget Password</a>
                    <a href="?container=register">Register</a>
                </div>
            </form>
            
            <script>
                document.getElementById('show-password').addEventListener('change', function() {
                    var pwd = document.getElementById('password');
                    pwd.type = this.checked ? 'text' : 'password';
                });
            </script>
        </div>
    </div>
    <?php
}

function showRegisterContainer() {
    ?>
    <div class="container">
        <div class="left-panel">
            <img src="logo.png" alt="Fitness Image" class="logo">
            <h1>STUDIO</h1>
        </div>
        <div class="right-panel">
            <a href="?container=login" class="back-button-top" style="font-size: 40px; font-weight: bold; color: gray; ">←</a>
            <h1>Ramon Magsaysay Memorial Colleges</h1>
            <h2>General Santos City</h2>
            <br>
            <img src="high_quality_logo.png" alt="school-logo" class="logos">
            <br>
            <div class="button-group">
                <a href="?container=student"><button onclick="handleClick('Student Athlete')">Student Athlete</button></a>
                <a href="?container=teachers"><button onclick="handleClick('Teachers / Instructors')">Teachers / Instructors</button></a>
                <a href="?container=staff"><button onclick="handleClick('Staff / Others')">Staff / Others</button></a>
            </div>
        </div>
    </div>
    <?php
}

function showStudentContainer() {
    ?>
    <a href="?container=register" class="back-button-top" style="font-size: 30px; font-weight: bold; color: whitesmoke;">←</a>
    <div class="container">
        <div class="left">
            <img src="logo.png" alt="logo">
            <h1>STUDIO</h1>
        </div>
        <div class="right">
            <h2>Student Athlete</h2>
            <br>
            <form onsubmit="confirmSubmission(event)">
                <input type="hidden" name="action" value="register">
                <input type="hidden" name="role" value="student">
                <div class="form-group">
                    <input type="text" id="family_name" name="family_name" placeholder="Family Name" required>
                    <input type="text" id="role" name="role_display" placeholder="Role" required>
                </div>
                <div class="form-group">
                    <input type="text" id="given_name" name="given_name" placeholder="Given Name" required>
                    <input type="email" id="email" name="email" placeholder="Email" required>
                </div>
                <div class="form-group">
                    <input type="text" id="middle_initial" name="middle_initial" placeholder="Middle Initial" required>
                    <input type="text" id="phone_number" name="phone_number" placeholder="Phone Number" required>
                </div>
                <div class="form-group">
                    <input type="text" id="sports_expertise" name="sports_expertise" placeholder="Sports Expertise / Others" required>
                    <input type="password" id="password" name="password" placeholder="Password" required>
                </div>
                <br>
                <div class="footer">
                    <button type="submit">CONFIRM</button>
                </div>
            </form>
        </div>
    </div>
    <script>
    async function confirmSubmission(event) {
        event.preventDefault();
        const form = event.target;
        const formData = new FormData(form);

        try {
            const response = await fetch('', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (result.success) {
                alert("Registration successful!");
                window.location.href = '?container=user_dashboard';
            } else {
                alert("Error: " + (result.errors?.join(", ") || "Unknown error"));
            }
        } catch (error) {
            alert("Network error. Please try again.");
            console.error("Error:", error);
        }
    }
    </script>
    <?php
}

function showTeachersContainer() {
    ?>
    <a href="?container=register" class="back-button-top" style="font-size: 30px; font-weight: bold; color: whitesmoke;">←</a>
    <div class="container">
        <div class="left">
            <img src="logo.png" alt="logo">
            <h1>STUDIO</h1>
        </div>
        <div class="right">
            <h2>Teachers / Instructors</h2>
            <br>
            <form onsubmit="confirmSubmission(event)">
                <input type="hidden" name="action" value="register">
                <input type="hidden" name="role" value="teachers">
                <div class="form-group">
                    <input type="text" id="family_name" name="family_name" placeholder="Family Name" required>
                    <input type="text" id="role" name="role_display" placeholder="Role" required>
                </div>
                <div class="form-group">
                    <input type="text" id="given_name" name="given_name" placeholder="Given Name" required>
                    <input type="email" id="email" name="email" placeholder="Email" required>
                </div>
                <div class="form-group">
                    <input type="text" id="middle_initial" name="middle_initial" placeholder="Middle Initial" required>
                    <input type="text" id="phone_number" name="phone_number" placeholder="Phone Number" required>
                </div>
                <div class="form-group">
                    <input type="text" id="sports_expertise" name="sports_expertise" placeholder="Sports Expertise / Others" required>
                    <input type="password" id="password" name="password" placeholder="Password" required>
                </div>
                <br>
                <div class="footer">
                    <button type="submit">CONFIRM</button>
                </div>
            </form>
        </div>
    </div>
    <script>
    async function confirmSubmission(event) {
        event.preventDefault();
        const form = event.target;
        const formData = new FormData(form);

        try {
            const response = await fetch('', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (result.success) {
                alert("Registration successful!");
                window.location.href = '?container=user_dashboard';
            } else {
                alert("Error: " + (result.errors?.join(", ") || "Unknown error"));
            }
        } catch (error) {
            alert("Network error. Please try again.");
            console.error("Error:", error);
        }
    }
    </script>
    <?php
}

function showStaffContainer() {
    ?>
    <a href="?container=register" class="back-button-top" style="font-size: 30px; font-weight: bold; color: whitesmoke;">←</a>
    <div class="container">
        <div class="left">
            <img src="logo.png" alt="logo">
            <h1>STUDIO</h1>
        </div>
        <div class="right">
            <h2>Staff / Others</h2>
            <br>
            <form onsubmit="confirmSubmission(event)">
                <input type="hidden" name="action" value="register">
                <input type="hidden" name="role" value="staff">
                <div class="form-group">
                    <input type="text" id="family_name" name="family_name" placeholder="Family Name" required>
                    <input type="text" id="role" name="role_display" placeholder="Role" required>
                </div>
                <div class="form-group">
                    <input type="text" id="given_name" name="given_name" placeholder="Given Name" required>
                    <input type="email" id="email" name="email" placeholder="Email" required>
                </div>
                <div class="form-group">
                    <input type="text" id="middle_initial" name="middle_initial" placeholder="Middle Initial" required>
                    <input type="text" id="phone_number" name="phone_number" placeholder="Phone Number" required>
                </div>
                <div class="form-group">
                    <input type="text" id="sports_expertise" name="sports_expertise" placeholder="Sports Expertise / Others" required>
                    <input type="password" id="password" name="password" placeholder="Password" required>
                </div>
                <br>
                <div class="footer">
                    <button type="submit">CONFIRM</button>
                </div>
            </form>
        </div>
    </div>
    <script>
    async function confirmSubmission(event) {
        event.preventDefault();
        const form = event.target;
        const formData = new FormData(form);

        try {
            const response = await fetch('', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (result.success) {
                alert("Registration successful!");
                window.location.href = '?container=user_dashboard';
            } else {
                alert("Error: " + (result.errors?.join(", ") || "Unknown error"));
            }
        } catch (error) {
            alert("Network error. Please try again.");
            console.error("Error:", error);
        }
    }
    </script>
    <?php
}

function showUserDashboard() {
    ?>
    <h1>User Dashboard</h1>
    <p>Welcome, <?= $_SESSION['username'] ?>!</p>
    <?php
}

function showAdminDashboard() {
    ?>
    <h1>Admin Dashboard</h1>
    <p>Welcome, <?= $_SESSION['username'] ?>!</p>
    <?php
}

// Main HTML structure
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Fitness Studio</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
        }
        .container {
            display: flex;
            height: 100vh;
        }
        .left-panel, .right-panel {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
        .left-panel {
            background-image: url('ss.png');
            background-size: 1000px 750px;
        }
        .right-panel {
            background-image: url('ss2.png');
            background-size: 1000px 750px;
            text-align: left;
        }
        .right-panel h1 {
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
            font-size: 30px;
        }
        .right-panel h2 {
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
            font-size: 25px;
        }
        .login-form {
            width: 100%;
            max-width: 350px;
        }
        .login-form label {
            font-size: 14px;
            margin-top: 10px;
            display: block;
            color: black;
        }
        .login-form input[type="text"],
        .login-form input[type="password"] {
            width: 100%;
            padding: 15px;
            margin-top: 5px;
            background: #d9d9d9;
            border: none;
            font-size: 20px;
        }
        .options {
            display: flex;
            align-items: center;
            margin: 5px 0 10px;
        }
        .options input[type="checkbox"] {
            margin-right: 8px;
        }
        .login-button-container {
            display: flex;
            justify-content: flex-end;
            padding-top: 10px;
        }
        .login-form button {
            padding: 10px 20px;
            background-color: white;
            border: none;
            font-weight: bold;
            font-size: 16px;
            cursor: pointer;
        }
        .login-form button:hover {
            background-color: #f0f0f0;
        }
        .links {
            margin-top: 10px;
            text-align: left;
        }
        .links a {
            font-size: 14px;
            color: #d3e5f9;
            text-decoration: underline;
            display: block;
            margin-top: 5px;
        }
        .logo {
            width: 500px;
            margin-bottom: 5px;
        }
        .logos {
            width: 200px;
            margin-bottom: 5px;
        }
        h1 {
            margin: 0;
            font-size: 30px;
        }
        .notification-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            display: none;
        }
        .notification-content {
            background-color: rgba(0, 0, 0, 0.8);
            padding: 20px 30px;
            border-radius: 10px;
            text-align: center;
            color: white;
            max-width: 300px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }
        .success-icon {
            color: #4CAF50;
            font-size: 40px;
            margin-bottom: 15px;
        }
        .error-icon {
            color: #F44336;
            font-size: 40px;
            margin-bottom: 15px;
        }
        .notification-text {
            margin-top: 10px;
            font-weight: bold;
            font-size: 16px;
        }
        .spinner {
            width: 40px;
            height: 40px;
            border: 4px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top: 4px solid #ffffff;
            animation: spin 1s linear infinite;
            margin: 0 auto 15px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .button-group button {
            width: 400px;
            padding: 20px;
            margin: 10px 0;
            font-size: 16px;
            background-color: whitesmoke;
            border: none;
            cursor: pointer;
            transition: 0.3s;
            border-radius: 4px;
        }
        .button-group button:hover {
            background-color:rgb(100, 233, 131);
        }
        .back-button-top {
            position: absolute;
            top: 20px;
            left: 20px;
            font-size: 24px;
            text-decoration: none;
            color: black;
        }
        .form-group {
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
            flex-wrap: wrap;
        }
        input {
            padding: 20px;
            width: 300px;
            border: none;
            border-radius: 4px;
            background-color: #ddd;
        }
        .footer {
            margin-top: 20px;
            text-align: center;
        }
        .footer button {
            padding: 12px 30px;
            margin: 0 16px;
            font-size: 16px;
            background-color: whitesmoke;
            border: none;
            border-radius: 8px;
            color: black;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .footer button:hover {
            background-color: #ccc;
        }
    </style>
</head>
<body>
    <?php
    // Show the appropriate container based on the page parameter
    switch ($page) {
        case 'login':
            showLoginContainer();
            break;
        case 'register':
            showRegisterContainer();
            break;
        case 'student':
            showStudentContainer();
            break;
        case 'teachers':
            showTeachersContainer();
            break;
        case 'staff':
            showStaffContainer();
            break;
        case 'user_dashboard':
            showUserDashboard();
            break;
        case 'admin_dashboard':
            showAdminDashboard();
            break;
        default:
            showLoginContainer();
    }
    ?>
</body>
</html>