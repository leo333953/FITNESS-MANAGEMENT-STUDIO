<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Store the requested URL for redirecting after login
    $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
    header("Location: login.php");
    exit();
}

// Verify session timeout (30 minutes)
if (isset($_SESSION['last_login']) && (time() - $_SESSION['last_login'] > 1800)) {
    session_unset();
    session_destroy();
    header("Location: login.php?timeout=1");
    exit();
}

// Update last activity time
$_SESSION['last_login'] = time();

// Function to check admin role
function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// Function to check user role
function isUser() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'user';
}
?>