<?php
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RMMC Admin Dashboard</title>
    <style>
        :root {  
            --primary-color: #1a365d; /* Dark blue */
            --secondary-color: #2b6cb0; /* Medium blue */
            --success-color: #38a169; /* Green */
            --warning-color: #dd6b20; /* Orange */
            --danger-color: #e53e3e; /* Red */
            --light-bg: #ebf8ff; /* Very light blue */
            --dark-text: #2d3748; /* Dark gray/blue */
            --light-text: #f7fafc; /* Off white */
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f5ff; /* Light blue background */
            color: var(--dark-text);
        }
        
        .container {
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background-color: var(--primary-color);
            color: var(--light-text);
            padding: 20px 0;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
        }
        
        .sidebar-header {
            text-align: center;
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-nav {
            flex: 1;
            overflow-y: auto;
            padding: 20px 0;
        }
        
        .sidebar-footer {
            padding: 20px;
            border-top: 1px solid rgba(255,255,255,0.1);
        }
        
        .nav-item {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: var(--light-text);
            text-decoration: none;
            transition: all 0.3s;
            margin: 5px 0;
        }
        
        .nav-item:hover {
            background-color: rgba(255,255,255,0.1);
        }

        .nav-item i {
            margin-right: 10px;
            font-size: 18px;
        }
        
        .logo {
            width: 80%;
            margin: 0 auto 20px;
            display: block;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .user-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 10px;
            object-fit: cover;
        }
        
        .user-info {
            flex: 1;
        }
        
        .user-name {
            font-weight: bold;
            margin-bottom: 3px;
        }
        
        .user-role {
            font-size: 12px;
            opacity: 0.8;
        }
        
        /* Main Content Styles */
        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        
        .top-bar {
            border-bottom: 1px solid #e2e8f0; /* Light blue-gray */
            background-color: white;
            padding: 15px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            z-index: 10;
        }
        
        .page-title {
            font-size: 22px;
            font-weight: 600;
            color: var(--primary-color);
        }
        
        .user-actions {
            display: flex;
            align-items: center;
        }
        
        .notification-bell, .user-menu {
            margin-left: 20px;
            cursor: pointer;
            position: relative;
        }
        
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background-color: var(--accent-color);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .content-area {
            flex: 1;
            padding: 25px;
            overflow-y: auto;
            background-color: #f0f5ff; /* Light blue background */
        }
        
        /* Dashboard Cards */
        .dashboard-cards {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
            justify-content: center;
            gap: 20px;
        }
        
        .card {
            background-color: white;
            border-left: 4px solid var(--secondary-color);
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            flex: 1;
            max-width: 300px;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .card-header {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .card-title {
            margin-right: 10px;
            font-weight: 600;
        }
        
        .card-icon {
            background-color: var(--secondary-color) !important;
            width: 40px;
            height: 40px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            margin-left: 10px;
        }
        
        .card-value {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 5px;
            text-align: center;
        }
        
        .card-footer {
            font-size: 12px;
            color: #7f8c8d;
            text-align: center;
        }
        
        /* Tables */
        .table-container {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            overflow: hidden;
            background-color: white;
            border: 1px solid #e2e8f0;
            max-width: 1000px;
            margin: 20px auto;
            width: 95%;
            max-height: 400px;
            overflow-y: auto;
            transition: max-height 0.3s ease-in-out;
        }
        
        .table-container.collapsed {
            max-height: 150px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ecf0f1;
        }
        
        th {
            background-color: var(--light-bg);
            font-weight: 600;
            background-color: #ebf8ff;
            color: var(--primary-color);
        }
        
        tr:hover {
            background-color: #f9f9f9;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .status-pending {
            background-color: #feebc8;
            color: #9c4221;
        }
        
        .status-completed {
            background-color: #c6f6d5;
            color: #276749;
        }
        
        .status-in-progress {
            background-color: #bee3f8;
            color: #2b6cb0;
        }
        
        .status-cancelled {
            background-color: #fed7d7;
            color: #9b2c2c;
        }
        
        /* Forms */
        .form-container {
            background-color: white;
            border-radius: 8px;
            padding: 25px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            max-width: 700px;
            margin: 0 auto;
        }
        
        .form-title {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 20px;
            color: var(--primary-color);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }
        
        .form-control {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--secondary-color);
            outline: none;
        }
        
        .form-actions {
            display: flex;
            justify-content: flex-end;
            margin-top: 30px;
        }
        
        .btn {
            padding: 10px 20px;
            border-radius: 4px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            border: none;
        }
        
        .btn-primary {
            background-color: var(--secondary-color);
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #2c5282;
        }
        
        .btn-secondary {
            background-color: #95a5a6;
            color: white;
            margin-right: 10px;
        }
        
        .btn-secondary:hover {
            background-color: #2c5282;
        }
        
        .btn-success {
            background-color: #38a169;
            color: white;
        }
        
        .btn-success:hover {
            background-color: #2f855a;
        }
        
        .btn-danger {
            background-color: var(--danger-color);
            color: white;
        }
        
        .btn-danger:hover {
            background-color: #c53030;
        }
        
        /* Section Styles */
        .section {
            display: none;
        }
        
        .section.active {
            display: block;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: auto;
            }
            
            .dashboard-cards {
                flex-direction: column;
                align-items: center;
            }
            
            .card {
                max-width: 100%;
                width: 100%;
            }
        }
        
        /* Action buttons */
        .action-btn {
            padding: 5px 10px;
            font-size: 12px;
            margin: 0 2px;
            min-width: 70px;
        }
        
        /* Filter controls */
        .filter-controls {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 15px;
            padding: 0 15px;
        }
        
        .filter-select {
            padding: 8px 12px;
            border-radius: 4px;
            border: 1px solid #ddd;
            margin-left: 10px;
        }
        
        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 100;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        
        .modal-content {
            background-color: white;
            margin: 10% auto;
            padding: 20px;
            border-radius: 8px;
            width: 80%;
            max-width: 600px;
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .close-btn {
            font-size: 24px;
            cursor: pointer;
        }
        
        /* Table wrapper for responsive scrolling */
        .table-wrapper {
            overflow-x: auto;
            width: 100%;
        }
        
        table {
            min-width: 100%;
            width: auto;
            white-space: nowrap;
        }
        
        th, td {
            padding: 12px 15px;
            white-space: nowrap;
            text-overflow: ellipsis;
            overflow: hidden;
            max-width: 200px;
        }
        
        /* Toggle button */
        .toggle-table-btn {
            display: block;
            margin: 10px auto;
            padding: 8px 15px;
            background-color: var(--secondary-color);
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .toggle-table-btn:hover {
            background-color: #2c5282;
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <img src="pictures/download.png" alt="RMMC Logo" class="logo">
                <div class="user-profile">
                    <div class="user-info">
                        <div class="user-name">Admin User</div>
                        <div class="user-role">Administrator</div>
                    </div>
                </div>
            </div>

            
            <div class="sidebar-nav">
                <a href="3.1(ADMINdashboard).php" class="nav-item">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                <a href="3.2(attendance).php" class="nav-item active">
                    <i class="fas fa-clipboard-check"></i> Attendance
                </a>
                <a href="3.3(maintenance).php" class="nav-item">
                    <i class="fas fa-tools"></i> Maintenance
                </a>
                <a href="3.4(appointments).php" class="nav-item">
                    <i class="fas fa-calendar-alt"></i> Appointments
                </a>
                <a href="3.5(messages).php" class="nav-item">
                    <i class="fas fa-envelope"></i> Messages
                </a>
                <a href="3.6(usermanagement).php" class="nav-item">
                    <i class="fas fa-users"></i> User Management
                </a>
                <a href="3.7(settings).php" class="nav-item">
                    <i class="fas fa-cog"></i> Settings
                </a>
            </div>
            
            <div class="sidebar-footer">
                <a href="1.1(homepage).php" class="nav-item" onclick="signOut()">
                    <i class="fas fa-sign-out-alt"></i> Sign Out
                </a>
            </div>
        </div>

        
        <!-- Main Content -->
        <div class="main-content">
            <div class="top-bar">
                <div class="page-title">Maintenance Requests</div>
            </div>
            
            <div class="content-area">
                <!-- Maintenance Requests Table -->
                <div class="table-container" id="maintenance-table-container">
                    <div class="filter-controls">
                        <label for="user-filter">Filter by User:</label>
                        <input type="text" id="user-filter" class="filter-select" placeholder="Search by name..." oninput="refreshMaintenanceTable()">
                        
                        <label for="status-filter">Filter by Status:</label>
                        <select id="status-filter" class="filter-select" onchange="refreshMaintenanceTable()">
                            <option value="all">All Statuses</option>
                            <option value="pending">Pending</option>
                            <option value="in-progress">In Progress</option>
                            <option value="completed">Completed</option>
                        </select>
                    </div>
                    
                    <button class="toggle-table-btn" onclick="toggleTable()">
                        <i class="fas fa-chevron-down" id="toggle-icon"></i> Toggle Table
                    </button>
                    
                    <div class="table-wrapper">
                        <table id="maintenance-table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Issue</th>
                                    <th>Date</th>
                                    <th>Urgency</th>
                                    <th>Status</th>
                                    <th>Scheduled Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Will be populated by JavaScript -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal for viewing/editing maintenance request -->
    <div id="maintenance-modal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Maintenance Request Details</h3>
                <span class="close-btn" onclick="closeModal()">&times;</span>
            </div>
            <form id="maintenance-form">
                <input type="hidden" id="request-id">
                <div class="form-group">
                    <label class="form-label">Name</label>
                    <input type="text" class="form-control" id="modal-name" readonly>
                </div>
                <div class="form-group">
                    <label class="form-label">Issue</label>
                    <textarea class="form-control" id="modal-issue" readonly></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Date</label>
                    <input type="text" class="form-control" id="modal-date" readonly>
                </div>
                <div class="form-group">
                    <label class="form-label">Urgency</label>
                    <input type="text" class="form-control" id="modal-urgency" readonly>
                </div>
                <div class="form-group">
                    <label class="form-label">Status</label>
                    <select class="form-control" id="modal-status">
                        <option value="pending">Pending</option>
                        <option value="in-progress">In Progress</option>
                        <option value="completed">Completed</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Scheduled Date</label>
                    <input type="date" class="form-control" id="modal-scheduled-date">
                </div>
                <div class="form-actions">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">Cancel</button>
                    <button type="button" class="btn btn-primary" onclick="saveMaintenanceRequest()">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        // Initialize maintenance requests data
        function initializeMaintenanceData() {
            if(!localStorage.getItem('maintenanceRequests')) {
                const sampleRequests = [
                    {
                        id: 1,
                        name: "John Doe",
                        issue: "Leaky faucet in bathroom",
                        date: new Date().toISOString().split('T')[0],
                        urgency: "high",
                        status: "pending",
                        scheduledDate: "",
                        adminNotes: ""
                    },
                    {
                        id: 2,
                        name: "Jane Smith",
                        issue: "Broken window in room 203",
                        date: new Date().toISOString().split('T')[0],
                        urgency: "medium",
                        status: "in-progress",
                        scheduledDate: new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0],
                        adminNotes: "Window replacement scheduled"
                    },
                    {
                        id: 3,
                        name: "Mike Johnson",
                        issue: "AC not working in room 105",
                        date: new Date().toISOString().split('T')[0],
                        urgency: "high",
                        status: "completed",
                        scheduledDate: new Date(Date.now() - 86400000).toISOString().split('T')[0],
                        adminNotes: "AC unit replaced, working properly now"
                    },
                    {
                        id: 4,
                        name: "Sarah Williams",
                        issue: "Door lock not working in room 312",
                        date: new Date().toISOString().split('T')[0],
                        urgency: "medium",
                        status: "pending",
                        scheduledDate: "",
                        adminNotes: ""
                    },
                    {
                        id: 5,
                        name: "David Brown",
                        issue: "Light fixture broken in hallway",
                        date: new Date().toISOString().split('T')[0],
                        urgency: "low",
                        status: "in-progress",
                        scheduledDate: new Date(Date.now() + 86400000).toISOString().split('T')[0],
                        adminNotes: "Parts ordered, will complete next week"
                    }
                ];
                localStorage.setItem('maintenanceRequests', JSON.stringify(sampleRequests));
            }
            refreshMaintenanceTable();
        }
        
        // Toggle table visibility
        function toggleTable() {
            const container = document.getElementById('maintenance-table-container');
            const icon = document.getElementById('toggle-icon');
            
            container.classList.toggle('collapsed');
            
            if (container.classList.contains('collapsed')) {
                icon.classList.remove('fa-chevron-down');
                icon.classList.add('fa-chevron-up');
            } else {
                icon.classList.remove('fa-chevron-up');
                icon.classList.add('fa-chevron-down');
            }
        }
        
        // Refresh maintenance table with filters
        function refreshMaintenanceTable() {
            const tbody = document.querySelector('#maintenance-table tbody');
            tbody.innerHTML = '';
            
            // Get filter values
            const userFilter = document.getElementById('user-filter').value.toLowerCase();
            const statusFilter = document.getElementById('status-filter').value;
            
            // Get all records from localStorage
            let requests = JSON.parse(localStorage.getItem('maintenanceRequests')) || [];
            
            // Apply filters
            let filteredRequests = requests;
            if (userFilter) {
                filteredRequests = filteredRequests.filter(request => 
                    request.name.toLowerCase().includes(userFilter)
                );
            }
            if (statusFilter !== 'all') {
                filteredRequests = filteredRequests.filter(request => request.status === statusFilter);
            }
            
            filteredRequests.forEach(request => {
                // Determine status class
                let statusClass = '';
                if (request.status === 'completed') statusClass = 'status-completed';
                else if (request.status === 'in-progress') statusClass = 'status-in-progress';
                else if (request.status === 'pending') statusClass = 'status-pending';
                
                // Determine urgency class
                let urgencyClass = '';
                if (request.urgency === 'high') urgencyClass = 'status-cancelled';
                else if (request.urgency === 'medium') urgencyClass = 'status-pending';
                else if (request.urgency === 'low') urgencyClass = 'status-completed';
                
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${request.name}</td>
                    <td>${request.issue}</td>
                    <td>${request.date}</td>
                    <td><span class="status-badge ${urgencyClass}">${request.urgency}</span></td>
                    <td><span class="status-badge ${statusClass}">${request.status}</span></td>
                    <td>${request.scheduledDate || '-'}</td>
                    <td>
                        <button class="btn btn-primary action-btn" onclick="viewMaintenanceRequest(${request.id})">
                            <i class="fas fa-eye"></i> View
                        </button>
                        ${request.status === 'pending' ? `
                        <button class="btn btn-success action-btn" onclick="approveMaintenanceRequest(${request.id})">
                            <i class="fas fa-check"></i> Approve
                        </button>
                        <button class="btn btn-danger action-btn" onclick="rejectMaintenanceRequest(${request.id})">
                            <i class="fas fa-times"></i> Reject
                        </button>` : ''}
                        ${request.status === 'in-progress' ? `
                        <button class="btn btn-success action-btn" onclick="completeMaintenanceRequest(${request.id})">
                            <i class="fas fa-check-circle"></i> Complete
                        </button>` : ''}
                        <button class="btn btn-danger action-btn" onclick="deleteMaintenanceRequest(${request.id})">
                            <i class="fas fa-trash"></i> Delete
                        </button>
                    </td>
                `;
                
                tbody.appendChild(row);
            });
        }
        
        // View maintenance request details in modal
        function viewMaintenanceRequest(requestId) {
            const requests = JSON.parse(localStorage.getItem('maintenanceRequests')) || [];
            const request = requests.find(r => r.id === requestId);
            
            if (request) {
                document.getElementById('request-id').value = request.id;
                document.getElementById('modal-name').value = request.name;
                document.getElementById('modal-issue').value = request.issue;
                document.getElementById('modal-date').value = request.date;
                document.getElementById('modal-urgency').value = request.urgency;
                document.getElementById('modal-status').value = request.status;
                document.getElementById('modal-scheduled-date').value = request.scheduledDate || '';
                
                document.getElementById('maintenance-modal').style.display = 'block';
            }
        }
        
        // Save changes to maintenance request
        function saveMaintenanceRequest() {
            const requestId = parseInt(document.getElementById('request-id').value);
            const status = document.getElementById('modal-status').value;
            const scheduledDate = document.getElementById('modal-scheduled-date').value;
            
            let requests = JSON.parse(localStorage.getItem('maintenanceRequests')) || [];
            const requestIndex = requests.findIndex(r => r.id === requestId);
            
            if (requestIndex !== -1) {
                requests[requestIndex].status = status;
                requests[requestIndex].scheduledDate = scheduledDate;
                
                localStorage.setItem('maintenanceRequests', JSON.stringify(requests));
                refreshMaintenanceTable();
                closeModal();
                alert('Maintenance request updated successfully');
            }
        }
        
        // Approve maintenance request
        function approveMaintenanceRequest(requestId) {
            if(confirm('Approve this maintenance request?')) {
                let requests = JSON.parse(localStorage.getItem('maintenanceRequests')) || [];
                const requestIndex = requests.findIndex(r => r.id === requestId);
                
                if(requestIndex !== -1) {
                    requests[requestIndex].status = 'in-progress';
                    localStorage.setItem('maintenanceRequests', JSON.stringify(requests));
                    refreshMaintenanceTable();
                    alert('Request approved and marked as in-progress');
                }
            }
        }
        
        // Reject maintenance request
        function rejectMaintenanceRequest(requestId) {
            if(confirm('Reject this maintenance request?')) {
                let requests = JSON.parse(localStorage.getItem('maintenanceRequests')) || [];
                const requestIndex = requests.findIndex(r => r.id === requestId);
                
                if(requestIndex !== -1) {
                    requests[requestIndex].status = 'rejected';
                    localStorage.setItem('maintenanceRequests', JSON.stringify(requests));
                    refreshMaintenanceTable();
                    alert('Request has been rejected');
                }
            }
        }
        
        // Complete maintenance request
        function completeMaintenanceRequest(requestId) {
            if(confirm('Mark this maintenance request as completed?')) {
                let requests = JSON.parse(localStorage.getItem('maintenanceRequests')) || [];
                const requestIndex = requests.findIndex(r => r.id === requestId);
                
                if(requestIndex !== -1) {
                    requests[requestIndex].status = 'completed';
                    localStorage.setItem('maintenanceRequests', JSON.stringify(requests));
                    refreshMaintenanceTable();
                    alert('Request marked as completed');
                }
            }
        }
        
        // Delete maintenance request
        function deleteMaintenanceRequest(requestId) {
            if(confirm('Are you sure you want to delete this maintenance request? This action cannot be undone.')) {
                let requests = JSON.parse(localStorage.getItem('maintenanceRequests')) || [];
                const updatedRequests = requests.filter(r => r.id !== requestId);
                localStorage.setItem('maintenanceRequests', JSON.stringify(updatedRequests));
                refreshMaintenanceTable();
                alert('Maintenance request has been deleted successfully');
            }
        }
        
        // Close modal
        function closeModal() {
            document.getElementById('maintenance-modal').style.display = 'none';
        }
        
        // Initialize when page loads
        window.onload = function() {
            initializeMaintenanceData();
        };
    </script>
</body>
</html>