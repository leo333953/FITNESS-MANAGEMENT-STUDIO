<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Multiplication Layout</title>
    <style>
        body {
            font-family: monospace;
            font-size: 24px;
            margin: 20px;
        }
        .equation {
            margin-bottom: 15px;
        }
        .multiplication {
            margin-bottom: 5px;
        }
        .top-number {
            margin-left: 15px;
        }
        .operator-line {
            border-top: 1px solid black;
            padding-top: 5px;
            width: 60px;
        }
    </style>
</head>
<body>
    <div class="equation">1.2 × 0.5 = 0.48</div>
    
    <div class="multiplication">
        <div class="top-number">1.2</div>
        <div>× 0.5</div>
        <div class="operator-line"></div>
        <div>0.48</div>
    </div>
</body>
</html>