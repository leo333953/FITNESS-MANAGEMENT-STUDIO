<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RMMC User Dashboard</title>
    <style>
      :root {
            --primary-color: #1a365d; /* Dark blue */
            --secondary-color: #2b6cb0; /* Medium blue */
            --success-color: #38a169; /* Green */
            --warning-color: #dd6b20; /* Orange */
            --danger-color: #e53e3e; /* Red */
            --light-bg: #ebf8ff; /* Very light blue */
            --dark-text: #2d3748; /* Dark gray/blue */
            --light-text: #f7fafc; /* Off white */
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f5ff; /* Light blue background */
            color: var(--dark-text);
        }
        
        .container {
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background-color: var(--primary-color);
            color: var(--light-text);
            padding: 20px 0;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
        }
        
        .sidebar-header {
            text-align: center;
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-nav {
            flex: 1;
            overflow-y: auto;
            padding: 20px 0;
        }
        
        .sidebar-footer {
            padding: 20px;
            border-top: 1px solid rgba(255,255,255,0.1);
        }
        
        .nav-item {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: var(--light-text);
            text-decoration: none;
            transition: all 0.3s;
            margin: 5px 0;
        }
        
        .nav-item:hover {
            background-color: rgba(255,255,255,0.1);
        }
       
        
        .nav-item i {
            margin-right: 10px;
            font-size: 18px;
        }
        
        .logo {
            width: 80%;
            margin: 0 auto 20px;
            display: block;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .user-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 10px;
            object-fit: cover;
        }
        
        .user-info {
            flex: 1;
        }
        
        .user-name {
            font-weight: bold;
            margin-bottom: 3px;
        }
        
        .user-role {
            font-size: 12px;
            opacity: 0.8;
        }
        
        /* Main Content Styles */
        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        
        .top-bar {
            border-bottom: 1px solid #e2e8f0; /* Light blue-gray */
            background-color: white;
            padding: 15px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            z-index: 10;
        }
        
        .page-title {
            font-size: 22px;
            font-weight: 600;
            color: var(--primary-color);
        }
        
        .user-actions {
            display: flex;
            align-items: center;
        }
        
        .notification-bell, .user-menu {
            margin-left: 20px;
            cursor: pointer;
            position: relative;
        }
        
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background-color: var(--accent-color);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .content-area {
            flex: 1;
            padding: 25px;
            overflow-y: auto;
            background-color: #f0f5ff; /* Light blue background */
        }
        
        /* Dashboard Cards */
        .dashboard-cards {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
            justify-content: center; /* Center the cards */
            gap: 20px; /* Space between cards */
        }
        
        .card {
            background-color: white;
            border-left: 4px solid var(--secondary-color);
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            flex: 1;
            max-width: 300px;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .card-header {
            display: flex;
            justify-content: center; /* Center the card header */
            align-items: center;
            margin-bottom: 15px; /* Space below the header */
        }
        .card-title {
            margin-right: 10px; /* Space between title and icon */
            font-weight: 600; /* Optional: Make the title bold */
        }
        .card-icon {
            background-color: var(--secondary-color) !important;
            width: 40px;
            height: 40px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            margin-left: 10px; /* Optional: Space to the left of the icon */
        }
        
        .card-value {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 5px;
            text-align: center;
        }
        
        .card-footer {
            font-size: 12px;
            color: #7f8c8d;
            text-align: center;
        }
        
        /* Forms */
        .form-container {
            background-color: white;
            border-radius: 8px;
            padding: 25px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            max-width: 600px; /* Reduced from 800px */
            margin: 0 auto;
            width: 90%;
        }
        
        .form-title {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 20px;
            color: var(--primary-color);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }
        
        .form-control {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--secondary-color);
            outline: none;
        }
        
        .btn {
            padding: 10px 20px;
            border-radius: 4px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            border: none;
        }
        
        .btn-primary {
            background-color: var(--secondary-color);
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #2c5282; /* Darker blue */
        }
        
        .btn-success {
            background-color: var(--success-color);
            color: white;
        }
        
        .btn-success:hover {
            background-color: #2f855a; /* Darker green */
        }
        
        .btn-danger {
            background-color: var(--danger-color);
            color: white;
        }
        
        .btn-danger:hover {
            background-color: #c53030; /* Darker red */
        }
        
        /* Tables */
        .table-container {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            overflow: hidden;
            background-color: white;
            border: 1px solid #e2e8f0;
            max-width: 800px; /* Reduced from 1000px */
            margin: 20px auto 0;
            width: 90%;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ecf0f1;
        }
        
        th {
            background-color: #ebf8ff; /* Very light blue */
            color: var(--primary-color);
            font-weight: 600;
        }
        
        tr:hover {
            background-color: #f9f9f9;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .status-pending {
            background-color: #feebc8; /* Light orange */
            color: #9c4221;
        }
        
        .status-completed {
            background-color: #c6f6d5; /* Light green */
            color: #276749;
        }
        
        /* Section styles */
        .section {
            display: none;
        }
        
        .section.active {
            display: block;
        }
        
        /* Dashboard logo styles */
        .dashboard-logo {
            display: block;
            width: 500px;
            max-width: 80%;
            margin: 0 auto 30px;
        }

        /* Table header with toggle */
        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            cursor: pointer;
            background-color: #f8fafc;
            border-bottom: 1px solid #e2e8f0;
        }

        .table-header h3 {
            margin: 0;
            color: var(--primary-color);
        }

        .toggle-icon {
            transition: transform 0.3s ease;
        }

        .collapsed .toggle-icon {
            transform: rotate(-90deg);
        }

        .collapsed + .table-wrapper {
            display: none;
        }

        .table-wrapper {
            max-height: 400px;
            overflow-y: auto;
            transition: max-height 0.3s ease;
        }

        /* Pagination controls */
        .pagination {
            display: flex;
            justify-content: center;
            padding: 15px;
            background-color: #f8fafc;
            border-top: 1px solid #e2e8f0;
        }

        .pagination button {
            margin: 0 5px;
            padding: 5px 10px;
            background-color: var(--secondary-color);
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .pagination button:disabled {
            background-color: #ccc;
            cursor: not-allowed;
        }

        .pagination-info {
            margin: 0 10px;
            display: flex;
            align-items: center;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: auto;
            }
            
            .dashboard-cards {
                flex-direction: column;
                align-items: center;
            }
            
            .card {
                max-width: 100%;
                width: 100%;
            }
            
            .form-container, .table-container {
                width: 95%;
            }
            
            .dashboard-logo {
                width: 300px;
            }
        }
        
        /* Action buttons */
        .action-btn {
            padding: 5px 10px;
            font-size: 12px;
            margin: 0 2px;
            min-width: 70px;
        }
    </style>

   
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <img src="pictures/download.png" alt="RMMC Logo" class="logo">
                <div class="user-profile">
                    <div class="user-info">
                        <div class="user-name">User Name</div>
                        <div class="user-role">Student/Staff</div>
                    </div>
                </div>
            </div>
            
             
            <div class="sidebar-nav">
                <a href="2.1(USERdashboard).php" class="nav-item active" onclick="showSection('dashboard', this)">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
               
                    <a href="2.0(account).php" class="nav-item" onclick="showSection('attendance', this)">
    <i class="fas fa-user"></i> Account
</a>

                </a>
                <a href="2.2(attendance).php" class="nav-item" onclick="showSection('attendance', this)">
                    <i class="fas fa-clipboard-check"></i> Attendance
                </a>
                <a href="2.3(maintenance).php" class="nav-item" onclick="showSection('maintenance', this)">
                    <i class="fas fa-tools"></i> Maintenance
                </a>
                <a href="2.4(appointments).php" class="nav-item" onclick="showSection('appointments', this)">
                    <i class="fas fa-calendar-alt"></i> Appointments
                </a>
                <a href="2.5(history).php" class="nav-item" onclick="showSection('history', this)">
                    <i class="fas fa-history"></i> History
                </a>

                      
            <div class="sidebar-footer">
                <a href="1.1(homepage).php" class="nav-item" onclick="signOut()">
                    <i class="fas fa-sign-out-alt"></i> Sign Out
                </a>
            </div>
            </div>
            
            
        </div>
        
    <!-- Main Content -->
    <div class="main-content">
      <div class="top-bar">
       
      </div>
      
<br>







            
<br>
<br>

<br>

<br>
<br>




           




<div class="table-container" style="margin-top: 20px;">
    <h3 style="padding: 15px 20px 0; margin-bottom: 0;">Today's Attendance Records</h3>
    <table id="attendance-table">
        <thead>
            <tr>
                <th>Date</th>
                <th>Check-in Time</th>
                <th>Check-out Time</th>
                <th>Duration</th>
                <th>Notes</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <!-- Will be populated by JavaScript -->
        </tbody>
    </table>
</div>

<br><br><br><br><br>

<div class="table-container">
    <h3 style="padding: 15px 20px 0; margin-bottom: 0;">Your Recent Requests</h3>
    <table id="maintenance-table">
        <thead>
            <tr>
                <th>Issue</th>
                <th>Urgency</th>
                <th>Status</th>
                <th>Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <!-- Will be populated by JavaScript -->
        </tbody>
    </table>
</div>

<br><br><br><br><br>

<div class="table-container">
    <h3 style="padding: 15px 20px 0; margin-bottom: 0;">Your Appointments</h3>
    <table id="appointment-table">
        <thead>
            <tr>
                <th>Purpose</th>
                <th>Date</th>
                <th>Time</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <!-- Will be populated by JavaScript -->
        </tbody>
    </table>
</div>
                    
<br>
<br>

<br>

<br>
<br>

                
         















                </div>
            </div>
        </div>
    </div>
       <div id="history-section" class="section"></div>


                         
   <script>
    // Sample data storage
    let attendanceRecords = [];
    let maintenanceRequests = [];
    let appointments = [];
    let currentUser = null;
    let checkedIn = false;
    
    // Initialize with sample data
    function initializeSampleData() {
        if(localStorage.getItem('attendanceRecords')) {
            attendanceRecords = JSON.parse(localStorage.getItem('attendanceRecords'));
        }
        
        if(localStorage.getItem('maintenanceRequests')) {
            maintenanceRequests = JSON.parse(localStorage.getItem('maintenanceRequests'));
        }
        
        if(localStorage.getItem('appointments')) {
            appointments = JSON.parse(localStorage.getItem('appointments'));
        }
        
        updateDashboard();
    }
    
    // Update dashboard counters
    function updateDashboard() {
        // Check if user is checked in
        const today = new Date().toISOString().split('T')[0];
        const userRecords = attendanceRecords.filter(record => 
            record.name === currentUser && record.date === today
        );
        
        const lastRecord = userRecords[userRecords.length - 1];
        
        if (lastRecord && !lastRecord.checkOut) {
            checkedIn = true;
            document.getElementById('attendance-status').textContent = 'Checked In';
            document.getElementById('attendance-time').textContent = 'Since ' + new Date(lastRecord.checkIn).toLocaleTimeString();
            document.getElementById('checkin-btn').style.display = 'none';
            document.getElementById('checkout-btn').style.display = 'inline-block';
        } else {
            checkedIn = false;
            document.getElementById('attendance-status').textContent = 'Not Checked In';
            document.getElementById('attendance-time').textContent = '-';
            document.getElementById('checkin-btn').style.display = 'inline-block';
            document.getElementById('checkout-btn').style.display = 'none';
        }
        
        // Update pending requests
        const pendingCount = maintenanceRequests.filter(req => req.status === 'pending').length;
        document.getElementById('pending-requests').textContent = pendingCount;
        
        // Update upcoming appointments
        const upcomingCount = appointments.filter(app => app.status === 'scheduled').length;
        document.getElementById('upcoming-appointments').textContent = upcomingCount;
    }
    
   // Update the refresh functions in history.php:

// Refresh attendance table
function refreshAttendanceTable() {
    const tbody = document.querySelector('#attendance-table tbody');
    tbody.innerHTML = '';
    
    // Get records from localStorage
    let records = JSON.parse(localStorage.getItem('attendanceRecords')) || [];
    
    // Filter for current user
    const userRecords = records.filter(record => record.name === currentUser);
    
    userRecords.forEach(record => {
        const checkInTime = record.checkIn ? new Date(record.checkIn).toLocaleTimeString() : '-';
        const checkOutTime = record.checkOut ? new Date(record.checkOut).toLocaleTimeString() : '-';
        
        // Calculate duration if both check-in and check-out exist
        let duration = '-';
        if (record.checkIn && record.checkOut) {
            const diff = new Date(record.checkOut) - new Date(record.checkIn);
            const hours = Math.floor(diff / (1000 * 60 * 60));
            const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
            duration = `${hours}h ${minutes}m`;
        }
        
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${record.date}</td>
            <td>${checkInTime}</td>
            <td>${checkOutTime}</td>
            <td>${duration}</td>
            <td>${record.notes || '-'}</td>
        `;
        
        tbody.appendChild(row);
    });
}


function viewUserMaintenanceHistory(userName) {
    const userRequests = maintenanceRequests.filter(req => req.name === userName);
    
    let historyHTML = `<h3>Maintenance History for ${userName}</h3><table class="table"><tr><th>Date</th><th>Issue</th><th>Urgency</th><th>Status</th></tr>`;
    
    userRequests.forEach(request => {
        historyHTML += `<tr>
            <td>${request.date}</td>
            <td>${request.issue}</td>
            <td>${request.urgency}</td>
            <td>${request.status}</td>
        </tr>`;
    });
    
    historyHTML += `</table>`;
    
    const win = window.open('', '_blank');
    win.document.write(historyHTML);
}



// Refresh maintenance table
function refreshMaintenanceTable() {
    const tbody = document.querySelector('#maintenance-table tbody');
    tbody.innerHTML = '';
    
    // Get requests from localStorage
    let requests = JSON.parse(localStorage.getItem('maintenanceRequests')) || [];
    
    // Filter for current user
    const userRequests = requests.filter(req => req.name === currentUser);
    
    userRequests.forEach(request => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${request.issue}</td>
            <td>${request.urgency}</td>
            <td><span class="status-badge ${request.status === 'completed' ? 'status-completed' : 'status-pending'}">${request.status}</span></td>
            <td>${request.date}</td>
        `;
        
        tbody.appendChild(row);
    });
}

// Refresh appointment table
function refreshAppointmentTable() {
    const tbody = document.querySelector('#appointment-table tbody');
    tbody.innerHTML = '';
    
    // Get appointments from localStorage
    let appointments = JSON.parse(localStorage.getItem('appointments')) || [];
    
    // Filter for current user
    const userAppointments = appointments.filter(app => app.name === currentUser);
    
    userAppointments.forEach(appointment => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${appointment.purpose}</td>
            <td>${appointment.date}</td>
            <td>${appointment.time}</td>
            <td><span class="status-badge ${appointment.status === 'completed' ? 'status-completed' : 'status-pending'}">${appointment.status}</span></td>
            <td>
                <button class="btn btn-primary" style="padding: 5px 10px; font-size: 12px;" onclick="cancelAppointment(${appointment.id})">
                    <i class="fas fa-times"></i> Cancel
                </button>
            </td>
        `;
        
        tbody.appendChild(row);
    });
}

// Update the initialization function:<script>
    // Update the initialization function:
    window.onload = function() {
        // Prompt for user name
        const name = prompt('Please enter your name to continue');
        if (name) {
            currentUser = name;
            
            // Load data from localStorage
            if(localStorage.getItem('attendanceRecords')) {
                attendanceRecords = JSON.parse(localStorage.getItem('attendanceRecords'));
            }
            if(localStorage.getItem('maintenanceRequests')) {
                maintenanceRequests = JSON.parse(localStorage.getItem('maintenanceRequests'));
            }
            if(localStorage.getItem('appointments')) {
                appointments = JSON.parse(localStorage.getItem('appointments'));
            }
            
            // Filter data for current user
            const userAttendance = attendanceRecords.filter(record => record.name === currentUser);
            const userMaintenance = maintenanceRequests.filter(req => req.name === currentUser);
            const userAppointments = appointments.filter(app => app.name === currentUser);
            
            // Populate attendance table
            const attendanceTbody = document.querySelector('#attendance-table tbody');
            attendanceTbody.innerHTML = '';
            userAttendance.forEach(record => {
                const checkInTime = record.checkIn ? new Date(record.checkIn).toLocaleTimeString() : '-';
                const checkOutTime = record.checkOut ? new Date(record.checkOut).toLocaleTimeString() : '-';
                let duration = '-';
                if (record.checkIn && record.checkOut) {
                    const diff = new Date(record.checkOut) - new Date(record.checkIn);
                    const hours = Math.floor(diff / (1000 * 60 * 60));
                    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
                    duration = `${hours}h ${minutes}m`;
                }
                
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${new Date(record.checkIn).toLocaleDateString()}</td>
                    <td>${checkInTime}</td>
                    <td>${checkOutTime}</td>
                    <td>${duration}</td>
                    <td>${record.notes || '-'}</td>
                    <td>
                        <button class="btn btn-primary" style="padding: 5px 10px; font-size: 12px;" onclick="deleteAttendanceRecord(${record.id})">
                            <i class="fas fa-trash"></i> Delete
                        </button>
                    </td>
                `;
                attendanceTbody.appendChild(row);
            });
            
            // Populate maintenance table
            const maintenanceTbody = document.querySelector('#maintenance-table tbody');
            maintenanceTbody.innerHTML = '';
            userMaintenance.forEach(request => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${request.issue}</td>
                    <td>${request.urgency}</td>
                    <td><span class="status-badge ${request.status === 'completed' ? 'status-completed' : 'status-pending'}">${request.status}</span></td>
                    <td>${request.date}</td>
                    <td>
                        <button class="btn btn-primary" style="padding: 5px 10px; font-size: 12px;" onclick="cancelMaintenanceRequest(${request.id})">
                            <i class="fas fa-times"></i> Cancel
                        </button>
                    </td>
                `;
                maintenanceTbody.appendChild(row);
            });
            
            // Populate appointment table
            const appointmentTbody = document.querySelector('#appointment-table tbody');
            appointmentTbody.innerHTML = '';
            userAppointments.forEach(appointment => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${appointment.purpose}</td>
                    <td>${appointment.date}</td>
                    <td>${appointment.time}</td>
                    <td><span class="status-badge ${appointment.status === 'completed' ? 'status-completed' : 'status-pending'}">${appointment.status}</span></td>
                    <td>
                        <button class="btn btn-primary" style="padding: 5px 10px; font-size: 12px;" onclick="cancelAppointment(${appointment.id})">
                            <i class="fas fa-times"></i> Cancel
                        </button>
                    </td>
                `;
                appointmentTbody.appendChild(row);
            });
        }
    };

    // Add these new functions to handle deletions/cancellations
    function deleteAttendanceRecord(id) {
        if(confirm('Are you sure you want to delete this attendance record?')) {
            attendanceRecords = attendanceRecords.filter(record => record.id !== id);
            localStorage.setItem('attendanceRecords', JSON.stringify(attendanceRecords));
            refreshAttendanceTable();
        }
    }

    function cancelMaintenanceRequest(id) {
        if(confirm('Are you sure you want to cancel this maintenance request?')) {
            maintenanceRequests = maintenanceRequests.filter(request => request.id !== id);
            localStorage.setItem('maintenanceRequests', JSON.stringify(maintenanceRequests));
            refreshMaintenanceTable();
        }
    }

    function cancelAppointment(id) {
        if(confirm('Are you sure you want to cancel this appointment?')) {
            appointments = appointments.filter(appointment => appointment.id !== id);
            localStorage.setItem('appointments', JSON.stringify(appointments));
            refreshAppointmentTable();
        }
    }

    // Update the refresh functions
    function refreshAttendanceTable() {
        const tbody = document.querySelector('#attendance-table tbody');
        tbody.innerHTML = '';
        
        let records = JSON.parse(localStorage.getItem('attendanceRecords')) || [];
        const userRecords = records.filter(record => record.name === currentUser);
        
        userRecords.forEach(record => {
            const checkInTime = record.checkIn ? new Date(record.checkIn).toLocaleTimeString() : '-';
            const checkOutTime = record.checkOut ? new Date(record.checkOut).toLocaleTimeString() : '-';
            let duration = '-';
            if (record.checkIn && record.checkOut) {
                const diff = new Date(record.checkOut) - new Date(record.checkIn);
                const hours = Math.floor(diff / (1000 * 60 * 60));
                const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
                duration = `${hours}h ${minutes}m`;
            }
            
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${record.date}</td>
                <td>${checkInTime}</td>
                <td>${checkOutTime}</td>
                <td>${duration}</td>
                <td>${record.notes || '-'}</td>
                <td>
                    <button class="btn btn-danger" style="padding: 5px 10px; font-size: 12px;" onclick="deleteAttendanceRecord(${record.id})">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </td>
            `;
            tbody.appendChild(row);
        });
    }

    function refreshMaintenanceTable() {
        const tbody = document.querySelector('#maintenance-table tbody');
        tbody.innerHTML = '';
        
        let requests = JSON.parse(localStorage.getItem('maintenanceRequests')) || [];
        const userRequests = requests.filter(req => req.name === currentUser);
        
        userRequests.forEach(request => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${request.issue}</td>
                <td>${request.urgency}</td>
                <td><span class="status-badge ${request.status === 'completed' ? 'status-completed' : 'status-pending'}">${request.status}</span></td>
                <td>${request.date}</td>
                <td>
                    <button class="btn btn-danger" style="padding: 5px 10px; font-size: 12px;" onclick="cancelMaintenanceRequest(${request.id})">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                </td>
            `;
            tbody.appendChild(row);
        });
    }

    function refreshAppointmentTable() {
        const tbody = document.querySelector('#appointment-table tbody');
        tbody.innerHTML = '';
        
        let appointments = JSON.parse(localStorage.getItem('appointments')) || [];
        const userAppointments = appointments.filter(app => app.name === currentUser);
        
        userAppointments.forEach(appointment => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${appointment.purpose}</td>
                <td>${appointment.date}</td>
                <td>${appointment.time}</td>
                <td><span class="status-badge ${appointment.status === 'completed' ? 'status-completed' : 'status-pending'}">${appointment.status}</span></td>
                <td>
                    <button class="btn btn-primary" style="padding: 5px 10px; font-size: 12px;" onclick="cancelAppointment(${appointment.id})">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                </td>
            `;
            tbody.appendChild(row);
        });
    }
</script>
</body>
</html>