<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RMMC User Dashboard</title>
    <style>
      :root {
            --primary-color: #1a365d;
            --secondary-color: #2b6cb0;
            --success-color: #38a169;
            --warning-color: #dd6b20;
            --danger-color: #e53e3e;
            --light-bg: #ebf8ff;
            --dark-text: #2d3748;
            --light-text: #f7fafc;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f5ff;
            color: var(--dark-text);
        }
        
        .container {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            background-color: var(--primary-color);
            color: var(--light-text);
            padding: 20px 0;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
        }
        
        .sidebar-header {
            text-align: center;
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-nav {
            flex: 1;
            overflow-y: auto;
            padding: 20px 0;
        }
        
        .sidebar-footer {
            padding: 20px;
            border-top: 1px solid rgba(255,255,255,0.1);
        }
        
        .nav-item {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: var(--light-text);
            text-decoration: none;
            transition: all 0.3s;
            margin: 5px 0;
        }
        
        .nav-item:hover {
            background-color: rgba(255,255,255,0.1);
        }
       
        .nav-item i {
            margin-right: 10px;
            font-size: 18px;
        }
        
        .logo {
            width: 80%;
            margin: 0 auto 20px;
            display: block;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .user-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 10px;
            object-fit: cover;
        }
        
        .user-info {
            flex: 1;
        }
        
        .user-name {
            font-weight: bold;
            margin-bottom: 3px;
        }
        
        .user-role {
            font-size: 12px;
            opacity: 0.8;
        }
        
        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        
        .top-bar {
            border-bottom: 1px solid #e2e8f0;
            background-color: white;
            padding: 15px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            z-index: 10;
        }
        
        .page-title {
            font-size: 22px;
            font-weight: 600;
            color: var(--primary-color);
        }
        
        .user-actions {
            display: flex;
            align-items: center;
        }
        
        .notification-bell, .user-menu {
            margin-left: 20px;
            cursor: pointer;
            position: relative;
        }
        
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background-color: var(--accent-color);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .content-area {
            flex: 1;
            padding: 25px;
            overflow-y: auto;
            background-color: #f0f5ff;
        }
        
        .dashboard-cards {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
            justify-content: center;
            gap: 20px;
        }
        
        .card {
            background-color: white;
            border-left: 4px solid var(--secondary-color);
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            transition: transform 0.3s, box-shadow 0.3s;
            flex: 1;
            max-width: 300px;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .card-header {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 15px;
        }
        .card-title {
            margin-right: 10px;
            font-weight: 600;
        }
        .card-icon {
            background-color: var(--secondary-color) !important;
            width: 40px;
            height: 40px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            margin-left: 10px;
        }
        
        .card-value {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 5px;
            text-align: center;
        }
        
        .card-footer {
            font-size: 12px;
            color: #7f8c8d;
            text-align: center;
        }
        
        .form-container {
            background-color: white;
            border-radius: 8px;
            padding: 25px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            max-width: 600px;
            margin: 0 auto;
            width: 90%;
        }
        
        .form-title {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 20px;
            color: var(--primary-color);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }
        
        .form-control {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--secondary-color);
            outline: none;
        }
        
        .btn {
            padding: 10px 20px;
            border-radius: 4px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            border: none;
        }
        
        .btn-primary {
            background-color: var(--secondary-color);
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #2c5282;
        }
        
        .btn-success {
            background-color: var(--success-color);
            color: white;
        }
        
        .btn-success:hover {
            background-color: #2f855a;
        }
        
        .btn-danger {
            background-color: var(--danger-color);
            color: white;
        }
        
        .btn-danger:hover {
            background-color: #c53030;
        }
        
        .table-container {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            overflow: hidden;
            background-color: white;
            border: 1px solid #e2e8f0;
            max-width: 800px;
            margin: 20px auto 0;
            width: 90%;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ecf0f1;
        }
        
        th {
            background-color: #ebf8ff;
            color: var(--primary-color);
            font-weight: 600;
        }
        
        tr:hover {
            background-color: #f9f9f9;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .status-pending {
            background-color: #feebc8;
            color: #9c4221;
        }
        
        .status-completed {
            background-color: #c6f6d5;
            color: #276749;
        }
        
        .status-in-progress {
            background-color: #bee3f8;
            color: #2b6cb0;
        }
        
        .status-scheduled {
            background-color: #e9d8fd;
            color: #553c9a;
        }
        
        .status-cancelled {
            background-color: #fed7d7;
            color: #9b2c2c;
        }
        
        .section {
            display: none;
        }
        
        .section.active {
            display: block;
        }
        
        .dashboard-logo {
            display: block;
            width: 500px;
            max-width: 80%;
            margin: 0 auto 30px;
        }

        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            cursor: pointer;
            background-color: #f8fafc;
            border-bottom: 1px solid #e2e8f0;
        }

        .table-header h3 {
            margin: 0;
            color: var(--primary-color);
        }

        .toggle-icon {
            transition: transform 0.3s ease;
        }

        .collapsed .toggle-icon {
            transform: rotate(-90deg);
        }

        .collapsed + .table-wrapper {
            display: none;
        }

        .table-wrapper {
            max-height: 400px;
            overflow-y: auto;
            transition: max-height 0.3s ease;
        }

        .pagination {
            display: flex;
            justify-content: center;
            padding: 15px;
            background-color: #f8fafc;
            border-top: 1px solid #e2e8f0;
        }

        .pagination button {
            margin: 0 5px;
            padding: 5px 10px;
            background-color: var(--secondary-color);
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .pagination button:disabled {
            background-color: #ccc;
            cursor: not-allowed;
        }

        .pagination-info {
            margin: 0 10px;
            display: flex;
            align-items: center;
        }
        
        .filter-controls {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 15px;
            padding: 0 15px;
        }
        
        .filter-select {
            padding: 8px 12px;
            border-radius: 4px;
            border: 1px solid #ddd;
            margin-left: 10px;
        }
        
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: auto;
            }
            
            .dashboard-cards {
                flex-direction: column;
                align-items: center;
            }
            
            .card {
                max-width: 100%;
                width: 100%;
            }
            
            .form-container, .table-container {
                width: 95%;
            }
            
            .dashboard-logo {
                width: 300px;
            }
            
            .filter-controls {
                flex-direction: column;
                align-items: flex-end;
            }
            
            .filter-select {
                margin: 5px 0;
            }
        }
        
        .action-btn {
            padding: 5px 10px;
            font-size: 12px;
            margin: 0 2px;
            min-width: 70px;
        }

        .table-wrapper {
            overflow-x: auto;
            width: 100%;
        }

        table {
            min-width: 100%;
            width: auto;
            white-space: nowrap;
        }

        th, td {
            padding: 12px 15px;
            white-space: nowrap;
            text-overflow: ellipsis;
            overflow: hidden;
            max-width: 200px;
        }

        .table-container {
            position: relative;
        }

        .table-container::after {
            content: '';
            position: absolute;
            right: 0;
            top: 0;
            bottom: 0;
            width: 20px;
            background: linear-gradient(to right, rgba(255,255,255,0), rgba(255,255,255,1));
            pointer-events: none;
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <div class="sidebar-header">
                <img src="pictures/download.png" alt="RMMC Logo" class="logo">
                <div class="user-profile">
                    <div class="user-info">
                        <div class="user-name">User Name</div>
                        <div class="user-role">Student/Staff</div>
                    </div>
                </div>
            </div>
            
            <div class="sidebar-nav">
                <a href="2.1(USERdashboard).php" class="nav-item active" onclick="showSection('dashboard', this)">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                  <a href="2.0(account).php" class="nav-item" onclick="showSection('attendance', this)">
    <i class="fas fa-user"></i> Account
</a>

                </a>
                <a href="2.2(attendance).php" class="nav-item" onclick="showSection('attendance', this)">
                    <i class="fas fa-clipboard-check"></i> Attendance
                </a>
                <a href="2.3(maintenance).php" class="nav-item" onclick="showSection('maintenance', this)">
                    <i class="fas fa-tools"></i> Maintenance
                </a>
                <a href="2.4(appointments).php" class="nav-item" onclick="showSection('appointments', this)">
                    <i class="fas fa-calendar-alt"></i> Appointments
                </a>

                 <a href="2.6(messages).php" class="nav-item">
                    <i class="fas fa-envelope"></i> Messages
                </a>

                <a href="2.5(history).php" class="nav-item" onclick="showSection('history', this)">
                    <i class="fas fa-history"></i> History
                </a>

                      
            <div class="sidebar-footer">
                <a href="1.1(homepage).php" class="nav-item" onclick="signOut()">
                    <i class="fas fa-sign-out-alt"></i> Sign Out
                </a>
            </div>
            </div>
        
        <div class="main-content">
            <div class="top-bar">
                <div class="page-title">History</div>
            </div>
            
            
                    <br>
                                        <br>

                                                            <br>

                                                                                <br>

                                                                                


            <div class="content-area">
                <div class="table-container" style="margin-top: 20px;">
                    <h3 style="padding: 15px 20px 0; margin-bottom: 0;">Your Attendance Records</h3>
                    <table id="attendance-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Check-in Time</th>
                                <th>Check-out Time</th>
                                <th>Duration</th>
                                <th>Notes</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>


                    <br>
                                        <br>

                                                            <br>

                                                                                <br>

                                                                                



                <div class="table-container" style="margin-top: 30px;">
                    <div class="filter-controls">
                        <label for="maintenance-filter">Filter Maintenance:</label>
                        <select id="maintenance-filter" class="filter-select" onchange="filterMaintenanceTable()">
                            <option value="all">All Requests</option>
                            <option value="pending">Pending</option>
                            <option value="in-progress">In Progress</option>
                            <option value="completed">Completed</option>
                            <option value="scheduled">Scheduled</option>
                        </select>
                    </div>
                    <h3 style="padding: 15px 20px 0; margin-bottom: 0;">Your Maintenance History</h3>
                    <table id="maintenance-table">
                        <thead>
                            <tr>
                                <th>Issue</th>
                                <th>Urgency</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th>Scheduled Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>



                    <br>
                                        <br>

                                                            <br>

                                                                                <br>

                                                                                

                <div class="table-container" style="margin-top: 30px;">
                    <div class="filter-controls">
                        <label for="appointment-filter">Filter Appointments:</label>
                        <select id="appointment-filter" class="filter-select" onchange="filterAppointmentTable()">
                            <option value="all">All Appointments</option>
                            <option value="scheduled">Scheduled</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                        </select>
                    </div>

               
                    <h3 style="padding: 15px 20px 0; margin-bottom: 0;">Your Appointment History</h3>
                    <table id="appointment-table">
                        <thead>
                            <tr>
                                <th>Purpose</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<script>
    let attendanceRecords = [];
    let maintenanceRequests = [];
    let appointments = [];
    let currentUser = null;
    let checkedIn = false;
    
    function initializeSampleData() {
        if(localStorage.getItem('attendanceRecords')) {
            attendanceRecords = JSON.parse(localStorage.getItem('attendanceRecords'));
        } else {
            attendanceRecords = [
                { id: 1, name: "Sample User", date: new Date().toISOString().split('T')[0], 
                  checkIn: new Date().toISOString(), checkOut: null, notes: "Sample record" }
            ];
            localStorage.setItem('attendanceRecords', JSON.stringify(attendanceRecords));
        }
        
        if(localStorage.getItem('maintenanceRequests')) {
            maintenanceRequests = JSON.parse(localStorage.getItem('maintenanceRequests'));
        } else {
            maintenanceRequests = [
                { id: 1, name: "Sample User", issue: "Sample issue", urgency: "medium", 
                  status: "pending", date: new Date().toISOString().split('T')[0], type: 'maintenance' }
            ];
            localStorage.setItem('maintenanceRequests', JSON.stringify(maintenanceRequests));
        }
        
        if(localStorage.getItem('appointments')) {
            appointments = JSON.parse(localStorage.getItem('appointments'));
        } else {
            appointments = [
                { id: 1, name: "Sample User", purpose: "Sample purpose", 
                  date: new Date().toISOString().split('T')[0], time: "14:00", status: "scheduled" }
            ];
            localStorage.setItem('appointments', JSON.stringify(appointments));
        }
        
        updateDashboard();
    }
    
    function updateDashboard() {
        const today = new Date().toISOString().split('T')[0];
        const userRecords = attendanceRecords.filter(record => 
            record.name === currentUser && record.date === today
        );
        
        const lastRecord = userRecords[userRecords.length - 1];
        
        if (lastRecord && !lastRecord.checkOut) {
            checkedIn = true;
            document.getElementById('attendance-status').textContent = 'Checked In';
            document.getElementById('attendance-time').textContent = 'Since ' + new Date(lastRecord.checkIn).toLocaleTimeString();
            document.getElementById('checkin-btn').style.display = 'none';
            document.getElementById('checkout-btn').style.display = 'inline-block';
        } else {
            checkedIn = false;
            document.getElementById('attendance-status').textContent = 'Not Checked In';
            document.getElementById('attendance-time').textContent = '-';
            document.getElementById('checkin-btn').style.display = 'inline-block';
            document.getElementById('checkout-btn').style.display = 'none';
        }
        
        const pendingCount = maintenanceRequests.filter(req => req.status === 'pending').length;
        document.getElementById('pending-requests').textContent = pendingCount;
        
        const upcomingCount = appointments.filter(app => app.status === 'scheduled').length;
        document.getElementById('upcoming-appointments').textContent = upcomingCount;
    }
    
    function filterMaintenanceTable() {
        const filterValue = document.getElementById('maintenance-filter').value;
        refreshMaintenanceTable(filterValue);
    }
    
    function filterAppointmentTable() {
        const filterValue = document.getElementById('appointment-filter').value;
        refreshAppointmentTable(filterValue);
    }
    
    function refreshAttendanceTable() {
        const tbody = document.querySelector('#attendance-table tbody');
        tbody.innerHTML = '';
        
        let records = JSON.parse(localStorage.getItem('attendanceRecords')) || [];
        const userRecords = records.filter(record => record.name === currentUser);
        
        userRecords.forEach(record => {
            const checkInTime = record.checkIn ? new Date(record.checkIn).toLocaleTimeString() : '-';
            const checkOutTime = record.checkOut ? new Date(record.checkOut).toLocaleTimeString() : '-';
            let duration = '-';
            if (record.checkIn && record.checkOut) {
                const diff = new Date(record.checkOut) - new Date(record.checkIn);
                const hours = Math.floor(diff / (1000 * 60 * 60));
                const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
                duration = `${hours}h ${minutes}m`;
            }
            
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${record.date}</td>
                <td>${checkInTime}</td>
                <td>${checkOutTime}</td>
                <td>${duration}</td>
                <td>${record.notes || '-'}</td>
                <td>
                    <button class="btn btn-danger action-btn" onclick="deleteAttendanceRecord(${record.id})">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </td>
            `;
            tbody.appendChild(row);
        });
    }
    
    function refreshMaintenanceTable(filter = 'all') {
        const tbody = document.querySelector('#maintenance-table tbody');
        tbody.innerHTML = '';
        
        let requests = JSON.parse(localStorage.getItem('maintenanceRequests')) || [];
        let userRequests = requests.filter(req => req.name === currentUser);
        
        if (filter !== 'all') {
            userRequests = userRequests.filter(req => req.status === filter);
        }
        
        userRequests.forEach(request => {
            let statusClass = '';
            if (request.status === 'completed') statusClass = 'status-completed';
            else if (request.status === 'pending') statusClass = 'status-pending';
            else if (request.status === 'in-progress') statusClass = 'status-in-progress';
            else if (request.status === 'scheduled') statusClass = 'status-scheduled';
            
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${request.issue}</td>
                <td>${request.urgency}</td>
                <td><span class="status-badge ${statusClass}">${request.status}</span></td>
                <td>${request.date}</td>
                <td>${request.scheduledDate || '-'}</td>
                <td>
                    ${request.status === 'pending' ? 
                        `<button class="btn btn-danger action-btn" onclick="cancelMaintenanceRequest(${request.id})">
                            <i class="fas fa-times"></i> Cancel
                        </button>` : 
                        `<button class="btn btn-primary action-btn" onclick="viewMaintenanceDetails(${request.id})">
                            <i class="fas fa-eye"></i> Details
                        </button>`
                    }
                </td>
            `;
            
            tbody.appendChild(row);
        });
    }
    
    function refreshAppointmentTable(filter = 'all') {
        const tbody = document.querySelector('#appointment-table tbody');
        tbody.innerHTML = '';
        
        let appointments = JSON.parse(localStorage.getItem('appointments')) || [];
        let userAppointments = appointments.filter(app => app.name === currentUser);
        
        if (filter !== 'all') {
            userAppointments = userAppointments.filter(app => app.status === filter);
        }
        
        userAppointments.forEach(appointment => {
            let statusClass = '';
            if (appointment.status === 'completed') statusClass = 'status-completed';
            else if (appointment.status === 'scheduled') statusClass = 'status-scheduled';
            else if (appointment.status === 'cancelled') statusClass = 'status-cancelled';
            
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${appointment.purpose}</td>
                <td>${appointment.date}</td>
                <td>${appointment.time}</td>
                <td><span class="status-badge ${statusClass}">${appointment.status}</span></td>
                <td>
                    ${appointment.status === 'scheduled' ? 
                        `<button class="btn btn-danger action-btn" onclick="cancelAppointment(${appointment.id})">
                            <i class="fas fa-times"></i> Cancel
                        </button>` : 
                        `<button class="btn btn-primary action-btn" onclick="viewAppointmentDetails(${appointment.id})">
                            <i class="fas fa-eye"></i> Details
                        </button>`
                    }
                </td>
            `;
            
            tbody.appendChild(row);
        });
    }
    
    function viewMaintenanceDetails(id) {
        const request = maintenanceRequests.find(req => req.id === id);
        if (request) {
            let details = `Maintenance Request Details\n\n`;
            details += `Issue: ${request.issue}\n`;
            details += `Urgency: ${request.urgency}\n`;
            details += `Status: ${request.status}\n`;
            details += `Date Submitted: ${request.date}\n`;
            if (request.scheduledDate) details += `Scheduled Date: ${request.scheduledDate}\n`;
            
            alert(details);
        }
    }
    
    function viewAppointmentDetails(id) {
        const appointment = appointments.find(app => app.id === id);
        if (appointment) {
            let details = `Appointment Details\n\n`;
            details += `Purpose: ${appointment.purpose}\n`;
            details += `Date: ${appointment.date}\n`;
            details += `Time: ${appointment.time}\n`;
            details += `Status: ${appointment.status}\n`;
            
            alert(details);
        }
    }
    
    function deleteAttendanceRecord(id) {
        if(confirm('Are you sure you want to delete this attendance record?')) {
            attendanceRecords = attendanceRecords.filter(record => record.id !== id);
            localStorage.setItem('attendanceRecords', JSON.stringify(attendanceRecords));
            refreshAttendanceTable();
        }
    }
    
    function cancelMaintenanceRequest(id) {
        if(confirm('Are you sure you want to cancel this maintenance request?')) {
            maintenanceRequests = maintenanceRequests.filter(req => req.id !== id);
            localStorage.setItem('maintenanceRequests', JSON.stringify(maintenanceRequests));
            refreshMaintenanceTable();
        }
    }
    
    function cancelAppointment(id) {
        if(confirm('Are you sure you want to cancel this appointment?')) {
            appointments = appointments.filter(app => app.id !== id);
            localStorage.setItem('appointments', JSON.stringify(appointments));
            refreshAppointmentTable();
        }
    }
    
    window.onload = function() {
        const name = prompt('Please enter your name to continue');
        if (name) {
            currentUser = name;
            
            if(localStorage.getItem('attendanceRecords')) {
                attendanceRecords = JSON.parse(localStorage.getItem('attendanceRecords'));
            }
            if(localStorage.getItem('maintenanceRequests')) {
                maintenanceRequests = JSON.parse(localStorage.getItem('maintenanceRequests'));
            }
            if(localStorage.getItem('appointments')) {
                appointments = JSON.parse(localStorage.getItem('appointments'));
            }
            
            refreshAttendanceTable();
            refreshMaintenanceTable();
            refreshAppointmentTable();
        }
    };
</script>
</body>
</html>