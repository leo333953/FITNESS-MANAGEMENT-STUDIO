<?php
// Your PHP code can go here if needed
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Fitness Studio Admin Dashboard</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    :root {
      --primary-color: #1a365d; /* Dark blue */
      --secondary-color: #2b6cb0; /* Medium blue */
      --warning-color: #dd6b20; /* Orange */
      --danger-color: #e53e3e; /* Red */
      --light-bg: #ebf8ff; /* Very light blue */
      --dark-text: #2d3748; /* Dark gray/blue */
      --light-text: #f7fafc; /* Off white */
      --fitness-primary: #1a365d; /* Dark blue */
    }
    
     
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f5ff; /* Light blue background */
            color: var(--dark-text);
        }
    
    
    .container {
      display: flex;
      min-height: 100vh;
    }
    
    /* Sidebar Styles */ 
    .sidebar {
      width: 250px;
      background-color: var(--fitness-primary);
      color: var(--light-text);
      padding: 20px 0;
      box-shadow: 2px 0 5px rgba(0,0,0,0.1); 
      display: flex;
      flex-direction: column;
    }
    
    .sidebar-header {
      text-align: center;
      padding: 0 20px 20px;
      border-bottom: 1px solid rgba(255,255,255,0.1);
    }
    
    .sidebar-nav {
      flex: 1;
      overflow-y: auto;
      padding: 20px 0;
    }
    
    .sidebar-footer {
      padding: 20px;
      border-top: 1px solid rgba(255,255,255,0.1);
    }
    
    .nav-item {
      display: flex;
      align-items: center;
      padding: 12px 20px;
      color: var(--light-text);
      text-decoration: none;
      transition: all 0.3s;
      margin: 5px 0;
    }
    
    .nav-item:hover {
      background-color: rgba(255,255,255,0.1);
    }
    
    .nav-item.active {
      background-color: var(--fitness-primary);
    }
    
    .nav-item i {
      margin-right: 10px;
      font-size: 18px;
    }
    
    .logo {
      width: 80%;
      margin: 0 auto 20px;
      display: block;
    }
    
    .user-profile {
      display: flex;
      align-items: center;
      margin-bottom: 20px;
    }
    
    .user-avatar {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      margin-right: 10px;
      object-fit: cover;
    }
    
    .user-info {
      flex: 1;
    }
    
    .user-name {
      font-weight: bold;
      margin-bottom: 3px;
    }
    
    .user-role {
      font-size: 12px;
      opacity: 0.8;
    }
    
    /* Main Content Styles */
    .main-content {
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden;
    }
    
    .top-bar {
      border-bottom: 1px solid #e2e8f0;
      background-color: white;
      padding: 15px 25px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
      z-index: 10;
    }
    
    .page-title {
      font-size: 22px;
      font-weight: 600;
      color: var(--primary-color);
    }
    
    .user-actions {
      display: flex;
      align-items: center;
    }
    
    .notification-bell, .user-menu {
      margin-left: 20px;
      cursor: pointer;
      position: relative;
    }
    
    .notification-badge {
      position: absolute;
      top: -5px;
      right: -5px;
      background-color: var(--secondary-color);
      color: white;
      border-radius: 50%;
      width: 18px;
      height: 18px;
      font-size: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    
    .content-area {
      flex: 1;
      padding: 25px;
      overflow-y: auto;
      background-color: #f0f5ff;
    }
    
    /* Dashboard Cards */
    .dashboard-cards {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
      gap: 20px;
      margin-bottom: 30px;
    }
    
    .card {
      background-color: white;
      border-left: 4px solid var(--fitness-primary);
      border-radius: 8px;
      padding: 20px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.05);
      transition: transform 0.3s, box-shadow 0.3s;
    }
    
    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    
    .card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 15px;
    }
    
    .card-title {
      font-size: 16px;
      font-weight: 600;
      color: var(--dark-text);
    }
    
    .card-icon {
      background-color: var(--fitness-primary);
      width: 40px;
      height: 40px;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      color: white;
    }
    
    .card-value {
      font-size: 24px;
      font-weight: 700;
      margin-bottom: 5px;
    }
    
    .card-footer {
      font-size: 12px;
      color: #7f8c8d;
    }
    
    /* Tables */
    .table-container {
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.05);
      overflow: hidden;
      border: 1px solid #e2e8f0;
    }
    
    table {
      width: 100%;
      border-collapse: collapse;
    }
    
    th, td {
      padding: 12px 15px;
      text-align: left;
      border-bottom: 1px solid #ecf0f1;
    }
    
    th {
      background-color: #ebf8ff;
      color: var(--primary-color);
      font-weight: 600;
    }
    
    tr:hover {
      background-color: #f9f9f9;
    }
    
    .status-badge {
      padding: 5px 10px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 500;
    }
    
    .status-pending {
      background-color: #feebc8;
      color: #9c4221;
    }
    
    .status-completed {
      background-color: #c6f6d5;
      color: #276749;
    }
    
    .status-cancelled {
      background-color: #fed7d7;
      color: #9b2c2c;
    }
    
    /* Button Group Styles */
    .button-group {
      display: flex;
      flex-direction: column;
      align-items: center;
      margin-top: 20px;
      width: 100%;
    }
    
    .button-group button {
      width: 80%;
      padding: 15px;
      margin: 10px 0;
      font-size: 16px;
      background-color: var(--fitness-primary);
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      transition: 0.3s;
    }
    
    .button-group button:hover {
      background-color: #142a4a;
    }
    
    /* Fitness Studio Specific Styles */
    .fitness-header {
      text-align: center;
      margin-bottom: 30px;
    }
    
    .fitness-logo {
      width: 300px;
      margin-bottom: 20px;
    }
    
    .fitness-title {
      font-size: 28px;
      color: var(--fitness-primary);
      margin-bottom: 10px;
    }
    
    .fitness-subtitle {
      font-size: 18px;
      color: #1a365d; ;
      margin-bottom: 20px;
    }
    
    /* Form Container Styles */
    .form-container {
      background-color: white;
      border-radius: 8px;
      padding: 25px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.05);
      margin: 0 auto;
      width: 400px; /* Narrower width for forms */
    }
    
    .form-title {
      font-size: 20px;
      font-weight: 600;
      margin-bottom: 20px;
      color: var(--primary-color);
      text-align: center;
    }
    
    .form-group {
      margin-bottom: 20px;
    }
    
    .form-label {
      display: block;
      margin-bottom: 8px;
      font-weight: 500;
    }
    
    .form-control {
      width: 100%;
      padding: 10px 5px;
      border: 1px solid #ddd;
      border-radius: 4px;
      font-size: 14px;
      transition: border-color 0.3s;
    }
    
    .form-control:focus {
      border-color: var(--secondary-color);
      outline: none;
    }
    
    .form-actions {
      display: flex;
      justify-content: space-between;
      margin-top: 30px;
    }
    
    .btn {
      padding: 10px 20px;
      border-radius: 4px;
      font-weight: 500;
      cursor: pointer;
      transition: all 0.3s;
      border: none;
    }
    
    .btn-primary {
      background-color: var(--secondary-color);
      color: white;
      flex: 1;
      margin-left: 10px;
    }
    
    .btn-primary:hover {
      background-color: var(--secondary-color);
    }
    
    .btn-secondary {
      background-color: #95a5a6;
      color: white;
      flex: 1;
      margin-right: 10px;
    }
    
    .btn-secondary:hover {
      background-color: #2c5282;
    }
    
    .btn-danger {
      background-color: var(--danger-color);
      color: white;
    }
    
    .btn-danger:hover {
      background-color: #c53030;
    }
    
    /* Section Styles */
    .section {
      display: none;
    }
    
    .section.active {
      display: block;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
      .container {
        flex-direction: column;
      }
      
      .sidebar {
        width: 100%;
        height: auto;
      }
      
      .dashboard-cards {
        grid-template-columns: 1fr;
      }
      
      .button-group button {
        width: 100%;
      }
      
      .form-container {
        width: 100%;
        padding: 15px;
      }
    }
  </style>
</head>

<body>
  <div class="container">
    <!-- Sidebar -->
    <div class="sidebar">
      <div class="sidebar-header">
        <img src="pictures/high_quality_logo.png" style="width: 100%" alt="Fitness Studio Logo" class="logo">
            <h2>RMMC</h2>

      </div>
    
      <div class="sidebar-nav">
        <a href="1.1(homepage).php" class="nav-item active" onclick="showSection('2(login).php', event)">
          <i class="fas fa-home"></i> Homepage
        </a>
        <a href="1.2(login).php" class="nav-item" onclick="showSection('login', event)">
          <i class="fas fa-user"></i> Log In
        </a>
        <a href="1.3(register).php" class="nav-item" onclick="showSection('register', event)">
          <i class="fas fa-user-plus"></i> Register
        </a>
        <a href="1.4(about).php" class="nav-item" onclick="showSection('about', event)">
          <i class="fas fa-history"></i> About
        </a>
        <a href="1.5(privacy).php" class="nav-item" onclick="showSection('privacy', event)">
          <i class="fas fa-user-shield"></i> Privacy & Policy
        </a>
        <a href="1.6(help).php" class="nav-item" onclick="showSection('help', event)">
          <i class="fas fa-question-circle"></i> Help
        </a>
      </div>
      
   
    </div>
    

      
        
 <!-- Main Content -->
    <div class="main-content">
      <div class="top-bar">
       
      </div>
      
<br>




<br>
<br>


        <!-- Help Section -->
          <div class="form-container" style="width: 80%; max-width: 800px;">
            <h2 class="form-title">Help Center</h2>
            <h3>Frequently Asked Questions</h3>
            <div class="faq-item">
              <h4>How do I reset my password?</h4>
              <p>Click on the "Forgot Password" link on the login page and follow the instructions sent to your registered email.</p>
            </div>
            <div class="faq-item">
              
            <h4>How can I update my personal information?</h4>
              <p>Visit the Registrar's Office or log in to your student portal to update your information.</p>
            </div>
            <div class="faq-item">
              <h4>Where can I view my grades?</h4>
              <p>Grades are available through the student portal at the end of each semester.</p>
            </div>
            <h3>Contact Support</h3>
            <p>For further assistance, please contact our support team:</p>
            <ul>
              <li>Email: support@rmmc.edu.ph</li>
              <li>Phone: (083) 123-4567</li>
              <li>Office Hours: Monday-Friday, 8:00 AM - 5:00 PM</li>
            </ul>
          </div>
   
          


   <script>
    // Show section based on menu selection
    function showSection(section, event) {
      // Hide all sections
      document.querySelectorAll('.section').forEach(sec => {
        sec.classList.remove('active');
      });
      
      // Show selected section
      document.getElementById(section + '-section').classList.add('active');
      
      // Update active menu item
      document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
      });
      
      // Set active state for clicked button
      event.currentTarget.classList.add('active');
    }
</script>
        
</body>

</html>

