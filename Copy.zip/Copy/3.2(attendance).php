<?php
// PHP code can be added here if needed
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RMMC Admin Dashboard</title>
    <style>
        :root {
            --primary-color: #1a365d; /* Dark blue */
            --secondary-color: #2b6cb0; /* Medium blue */
            --success-color: #38a169; /* Green */
            --warning-color: #dd6b20; /* Orange */
            --danger-color: #e53e3e; /* Red */
            --light-bg: #ebf8ff; /* Very light blue */
            --dark-text: #2d3748; /* Dark gray/blue */
            --light-text: #f7fafc; /* Off white */
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f5ff; /* Light blue background */
            color: var(--dark-text);
        }
        
        .container {
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background-color: var(--primary-color);
            color: var(--light-text);
            padding: 20px 0;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
        }
        
        .sidebar-header {
            text-align: center;
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-nav {
            flex: 1;
            overflow-y: auto;
            padding: 20px 0;
        }
        
        .sidebar-footer {
            padding: 20px;
            border-top: 1px solid rgba(255,255,255,0.1);
        }
        
        .nav-item {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: var(--light-text);
            text-decoration: none;
            transition: all 0.3s;
            margin: 5px 0;
        }
        
        .nav-item:hover {
            background-color: rgba(255,255,255,0.1);
        }
        
        .nav-item i {
            margin-right: 10px;
            font-size: 18px;
        }
        
        .logo {
            width: 80%;
            margin: 0 auto 20px;
            display: block;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .user-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 10px;
            object-fit: cover;
        }
        
        .user-info {
            flex: 1;
        }
        
        .user-name {
            font-weight: bold;
            margin-bottom: 3px;
        }
        
        .user-role {
            font-size: 12px;
            opacity: 0.8;
        }
        
        /* Main Content Styles */
        .main-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        
        .top-bar {
            border-bottom: 1px solid #e2e8f0; /* Light blue-gray */
            background-color: white;
            padding: 15px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            z-index: 10;
        }
        
        .page-title {
            font-size: 22px;
            font-weight: 600;
            color: var(--primary-color);
        }
        
        .user-actions {
            display: flex;
            align-items: center;
        }
        
        .notification-bell, .user-menu {
            margin-left: 20px;
            cursor: pointer;
            position: relative;
        }
        
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background-color: var(--accent-color);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .content-area {
            flex: 1;
            padding: 25px;
            overflow-y: auto;
            background-color: #f0f5ff; /* Light blue background */
        }
        
        /* Forms */
        .form-container {
            background-color: white;
            border-radius: 8px;
            padding: 25px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            max-width: 800px;
            margin: 0 auto;
            width: 90%;
        }
        
        .form-title {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 20px;
            color: var(--primary-color);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }
        
        .form-control {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            transition: border-color 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--secondary-color);
            outline: none;
        }
        
        .btn {
            padding: 10px 20px;
            border-radius: 4px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            border: none;
        }
        
        .btn-primary {
            background-color: var(--secondary-color);
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #2c5282;
        }
        
        .btn-success {
            background-color: var(--success-color);
            color: white;
        }
        
        .btn-success:hover {
            background-color: #2f855a;
        }
        
        .btn-danger {
            background-color: var(--danger-color);
            color: white;
        }
        
        .btn-danger:hover {
            background-color: #c53030;
        }
        
        .btn-info {
            background-color: #4299e1;
            color: white;
        }
        
        .btn-info:hover {
            background-color: #3182ce;
        }
        
        /* Tables */
        .table-container {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            overflow: hidden;
            background-color: white;
            border: 1px solid #e2e8f0;
            max-width: 1000px;
            margin: 20px auto 0;
            width: 90%;
            max-height: 400px; /* Set a max height for the container */
            overflow-y: auto; /* Enable vertical scrolling */
            transition: max-height 0.3s ease-in-out;
        }
        
        .table-container.collapsed {
            max-height: 150px; /* Reduced height when collapsed */
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ecf0f1;
        }
        
        th {
            background-color: #ebf8ff;
            color: var(--primary-color);
            font-weight: 600;
        }
        
        tr:hover {
            background-color: #f9f9f9;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        
        .status-completed {
            background-color: #c6f6d5;
            color: #276749;
        }
        
        .status-in-progress {
            background-color: #bee3f8;
            color: #2b6cb0;
        }
        
        /* Action buttons */
        .action-btn {
            padding: 5px 10px;
            font-size: 12px;
            margin: 0 2px;
            min-width: 70px;
        }
        
        /* Filter controls */
        .filter-controls {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .filter-controls .form-group {
            flex: 1;
        }
        
        /* Toggle button for table */
        .toggle-table-btn {
            display: block;
            margin: 10px auto;
            padding: 8px 15px;
            background-color: var(--secondary-color);
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .toggle-table-btn:hover {
            background-color: #2c5282;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
                height: auto;
            }
            
            .form-container, .table-container {
                width: 95%;
            }
            
            .filter-controls {
                flex-direction: column;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <img src="pictures/download.png" alt="RMMC Logo" class="logo">
                <div class="user-profile">
                    <div class="user-info">
                        <div class="user-name">Admin User</div>
                        <div class="user-role">Administrator</div>
                    </div>
                </div>
            </div>
            
            <div class="sidebar-nav">
                <a href="3.1(ADMINdashboard).php" class="nav-item">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
                <a href="3.2(attendance).php" class="nav-item active">
                    <i class="fas fa-clipboard-check"></i> Attendance
                </a>
                <a href="3.3(maintenance).php" class="nav-item">
                    <i class="fas fa-tools"></i> Maintenance
                </a>
                <a href="3.4(appointments).php" class="nav-item">
                    <i class="fas fa-calendar-alt"></i> Appointments
                </a>
                <a href="3.5(messages).php" class="nav-item">
                    <i class="fas fa-envelope"></i> Messages
                </a>
                <a href="3.6(usermanagement).php" class="nav-item">
                    <i class="fas fa-users"></i> User Management
                </a>
                <a href="3.7(settings).php" class="nav-item">
                    <i class="fas fa-cog"></i> Settings
                </a>
            </div>
            
            <div class="sidebar-footer">
                <a href="1.1(homepage).php" class="nav-item" onclick="signOut()">
                    <i class="fas fa-sign-out-alt"></i> Sign Out
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="top-bar">
                <div class="page-title">Attendance Management</div>
            </div>
            
            <div class="content-area">
                <div class="form-container">
                    <h2 class="form-title">Attendance Records</h2>
                    
                    <div class="filter-controls">
                        <div class="form-group">
                            <label class="form-label">Filter by User</label>
                            <input type="text" class="form-control" id="user-filter" placeholder="Search by name..." oninput="refreshAttendanceTable()">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Filter by Date</label>
                            <input type="date" class="form-control" id="date-filter" onchange="refreshAttendanceTable()">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Filter by Status</label>
                            <select class="form-control" id="status-filter" onchange="refreshAttendanceTable()">
                                <option value="all">All Statuses</option>
                                <option value="completed">Completed</option>
                                <option value="in-progress">In Progress</option>
                            </select>
                        </div>
                    </div>
                    
                    <button class="toggle-table-btn" onclick="toggleTable()">
                        <i class="fas fa-chevron-down" id="toggle-icon"></i> Toggle Table
                    </button>
                    
                    <div class="table-container" id="attendance-table-container">
                        <table id="attendance-table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Date</th>
                                    <th>Check-in Time</th>
                                    <th>Check-out Time</th>
                                    <th>Duration</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Will be populated by JavaScript -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Toggle table visibility
        function toggleTable() {
            const container = document.getElementById('attendance-table-container');
            const icon = document.getElementById('toggle-icon');
            
            container.classList.toggle('collapsed');
            
            if (container.classList.contains('collapsed')) {
                icon.classList.remove('fa-chevron-down');
                icon.classList.add('fa-chevron-up');
            } else {
                icon.classList.remove('fa-chevron-up');
                icon.classList.add('fa-chevron-down');
            }
        }

        // Function to refresh the attendance table with filters
        function refreshAttendanceTable() {
            const tbody = document.querySelector('#attendance-table tbody');
            tbody.innerHTML = '';
            
            // Get filter values
            const userFilter = document.getElementById('user-filter').value.toLowerCase();
            const dateFilter = document.getElementById('date-filter').value;
            const statusFilter = document.getElementById('status-filter').value;
            
            // Get all records from localStorage
            let records = JSON.parse(localStorage.getItem('attendanceRecords')) || [];
            
            // Apply filters
            let filteredRecords = records;
            if (userFilter) {
                filteredRecords = filteredRecords.filter(record => 
                    record.name.toLowerCase().includes(userFilter)
                );
            }
            if (dateFilter) {
                filteredRecords = filteredRecords.filter(record => 
                    new Date(record.checkIn).toISOString().split('T')[0] === dateFilter
                );
            }
            if (statusFilter !== 'all') {
                filteredRecords = filteredRecords.filter(record => {
                    const status = record.checkOut ? 'completed' : 'in-progress';
                    return status === statusFilter;
                });
            }
            
            filteredRecords.forEach(record => {
                const checkInDate = new Date(record.checkIn);
                const checkInTime = checkInDate.toLocaleTimeString();
                const checkOutTime = record.checkOut ? new Date(record.checkOut).toLocaleTimeString() : '-';
                
                // Calculate duration if both check-in and check-out exist
                let duration = '-';
                if (record.checkIn && record.checkOut) {
                    const diff = new Date(record.checkOut) - checkInDate;
                    const hours = Math.floor(diff / (1000 * 60 * 60));
                    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
                    duration = `${hours}h ${minutes}m`;
                }
                
                // Determine status
                let status = 'Completed';
                let statusClass = 'status-completed';
                if (!record.checkOut) {
                    status = 'In Progress';
                    statusClass = 'status-in-progress';
                }
                
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${record.name}</td>
                    <td>${checkInDate.toLocaleDateString()}</td>
                    <td>${checkInTime}</td>
                    <td>${checkOutTime}</td>
                    <td>${duration}</td>
                    <td><span class="status-badge ${statusClass}">${status}</span></td>
                    <td>
                        <button class="btn btn-primary action-btn" onclick="viewAttendanceRecord(${record.id})">
                            <i class="fas fa-eye"></i> View
                        </button>
                        <button class="btn btn-info action-btn" onclick="viewUserAttendanceHistory('${record.name}')">
                            <i class="fas fa-history"></i> History
                        </button>
                        ${!record.checkOut ? `
                        <button class="btn btn-danger action-btn" onclick="forceCheckout(${record.id})">
                            <i class="fas fa-sign-out-alt"></i> Force Checkout
                        </button>` : ''}
                        
                        <button class="btn btn-danger action-btn" onclick="deleteAttendanceRecord(${record.id})">
                            <i class="fas fa-trash"></i> Delete
                        </button>
                    </td>
                `;
                
                tbody.appendChild(row);
            });
        }
        
        // Function to delete an attendance record
        function deleteAttendanceRecord(recordId) {
            if(confirm('Are you sure you want to delete this attendance record? This action cannot be undone.')) {
                let records = JSON.parse(localStorage.getItem('attendanceRecords')) || [];
                const updatedRecords = records.filter(r => r.id !== recordId);
                localStorage.setItem('attendanceRecords', JSON.stringify(updatedRecords));
                refreshAttendanceTable();
                alert('Attendance record has been deleted successfully');
            }
        }
        
        // Function to force checkout a user
        function forceCheckout(recordId) {
            if(confirm('Are you sure you want to force checkout this user?')) {
                let records = JSON.parse(localStorage.getItem('attendanceRecords')) || [];
                const recordIndex = records.findIndex(r => r.id === recordId);
                
                if(recordIndex !== -1) {
                    records[recordIndex].checkOut = new Date().toISOString();
                    localStorage.setItem('attendanceRecords', JSON.stringify(records));
                    refreshAttendanceTable();
                    alert('User has been checked out successfully');
                }
            }
        }
        
        // Function to view a single attendance record
        function viewAttendanceRecord(recordId) {
            const records = JSON.parse(localStorage.getItem('attendanceRecords')) || [];
            const record = records.find(r => r.id === recordId);
            
            if (record) {
                const checkInDate = new Date(record.checkIn);
                const checkOutDate = record.checkOut ? new Date(record.checkOut) : null;
                
                let details = `Attendance Record Details\n\n`;
                details += `Name: ${record.name}\n`;
                details += `Date: ${checkInDate.toLocaleDateString()}\n`;
                details += `Check-in Time: ${checkInDate.toLocaleTimeString()}\n`;
                details += `Check-out Time: ${checkOutDate ? checkOutDate.toLocaleTimeString() : 'Not checked out yet'}\n`;
                
                if (checkOutDate) {
                    const duration = (checkOutDate - checkInDate) / (1000 * 60 * 60);
                    details += `Duration: ${duration.toFixed(2)} hours\n`;
                }
                
                if (record.notes) {
                    details += `Notes: ${record.notes}\n`;
                }
                
                alert(details);
            }
        }
        
        // Function to view user's attendance history
        function viewUserAttendanceHistory(userName) {
            const records = JSON.parse(localStorage.getItem('attendanceRecords')) || [];
            const userRecords = records.filter(r => r.name === userName);
            
            if (userRecords.length === 0) {
                alert(`No attendance records found for ${userName}`);
                return;
            }
            
            let history = `Attendance History for ${userName}\n\n`;
            userRecords.forEach(record => {
                const checkInDate = new Date(record.checkIn);
                const checkOutDate = record.checkOut ? new Date(record.checkOut) : null;
                
                history += `Date: ${checkInDate.toLocaleDateString()}\n`;
                history += `Check-in: ${checkInDate.toLocaleTimeString()}\n`;
                history += `Check-out: ${checkOutDate ? checkOutDate.toLocaleTimeString() : 'Not checked out'}\n`;
                
                if (checkOutDate) {
                    const duration = (checkOutDate - checkInDate) / (1000 * 60 * 60);
                    history += `Duration: ${duration.toFixed(2)} hours\n`;
                }
                
                history += `Status: ${record.checkOut ? 'Completed' : 'In Progress'}\n`;
                history += '------------------------\n';
            });
            
            alert(history);
        }
        
        // Initialize the page
        window.onload = function() {
            // Set up event listeners for filters
            document.getElementById('user-filter').addEventListener('input', refreshAttendanceTable);
            document.getElementById('date-filter').addEventListener('change', refreshAttendanceTable);
            document.getElementById('status-filter').addEventListener('change', refreshAttendanceTable);
            
            // Load initial data
            refreshAttendanceTable();
        };
        
        // Function to sign out (placeholder)
        function signOut() {
            // Add sign out functionality here
            console.log('Signing out...');
        }
    </script>
</body>
</html>